make-cert.cmd  to create the cert
launched MMC and exported the above generated certificate to get the pfx file
the password used while exporting was SQL2012123!!!

used the following doc:
VM Host c$\MSFT\DOD-IG\pki-cert\'Data Encryption at Rest.docx'

C:\Program Files\Microsoft\PVKConverter\PVKConverter.exe -i nkaSQL2012TDE.pfx -o nkaSQL2012VM -d SQL2012123!!! -e SQL2012123!!!