make-cert.cmd  to create the cert
launched MMC and exported the above generated certificate to get the pfx file
the password used while exporting was SQL2012123!!!

used the following doc:
VM Host c$\MSFT\DOD-IG\pki-cert\'Data Encryption at Rest.docx'


PVKConverter.exe -i nkaSQL2012TDE.pfx -o nkaSQL2012VM -d 'SQL2012123!!!' -e 'SQL2012123!!!'

select * from sys.symmetric_keys
GO
--drop master key
--Create Database Master-Key
CREATE MASTER KEY ENCRYPTION BY PASSWORD = 'SQL2012123!!!'
GO

--Verify the DMK is created :
select * from sys.symmetric_keys
GO
CREATE CERTIFICATE TDE_CERT 
FROM FILE = 'C:\MSFT\cert.new\pvkCreated\nkaSQL2012VM_1.cer' 
WITH PRIVATE KEY ( FILE = 'C:\MSFT\cert.new\pvkCreated\nkaSQL2012VM_1.pvk', 
DECRYPTION BY PASSWORD = 'SQL2012123!!!')

----

use SysEvents
GO
select * from sys.databases
--	Check if the TDE DEK symmetric key exists for the database, if not create it.
select DB_NAME(8), percent_complete, * from sys.dm_database_encryption_keys

--Create the TDE DEK symmetric key (if not exists), encrypted by server TDE certificate.
CREATE DATABASE ENCRYPTION KEY WITH ALGORITHM = AES_256 ENCRYPTION BY SERVER CERTIFICATE TDE_CERT

--Turn ON Database encryption � TDE. This is Asynchronous process. 
ALTER DATABASE SysEvents SET ENCRYPTION ON
---

CREATE DATABASE ENCRYPTION KEY WITH ALGORITHM = AES_256 ENCRYPTION BY SERVER CERTIFICATE SysEvents_CERT


ALTER DATABASE SysEvents SET ENCRYPTION ON

