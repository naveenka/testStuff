--logins mapped to database users
declare @cmd varchar(2200),
@database sysname

if exists (select name from tempdb..sysobjects where name like '%#logins_users%')
drop table #logins_users

create table #logins_users
(server_name varchar(100),
database_name varchar(300),
username varchar(100),
loginname varchar(100),
server_role VARCHAR(20))

declare cur cursor for
select name from master..sysdatabases

open cur
fetch next from cur into @database

WHILE @@FETCH_STATUS = 0
begin
set @cmd = 'select @@Servername, ''' + @database + ''', l.name as [login name], u.name as [user name],  
''sysadmin''
from [' + @database + ']..sysusers u inner join master..syslogins l
on u.sid=l.sid WHERE l.sysadmin = 1 
UNION
select @@Servername, ''' + @database + ''', l.name as [login name], u.name as [user name],  
''securityadmin''
from [' + @database + ']..sysusers u inner join master..syslogins l
on u.sid=l.sid WHERE l.securityadmin = 1 
UNION
select @@Servername, ''' + @database + ''', l.name as [login name], u.name as [user name],  
''serveradmin''
from [' + @database + ']..sysusers u inner join master..syslogins l
on u.sid=l.sid WHERE l.serveradmin = 1 
UNION
select @@Servername, ''' + @database + ''', l.name as [login name], u.name as [user name],  
''setupadmin''
from [' + @database + ']..sysusers u inner join master..syslogins l
on u.sid=l.sid WHERE l.setupadmin = 1 
UNION
select @@Servername, ''' + @database + ''', l.name as [login name], u.name as [user name],  
''processadmin''
from [' + @database + ']..sysusers u inner join master..syslogins l
on u.sid=l.sid WHERE l.processadmin = 1 
UNION
select @@Servername, ''' + @database + ''', l.name as [login name], u.name as [user name],  
''diskadmin''
from [' + @database + ']..sysusers u inner join master..syslogins l
on u.sid=l.sid WHERE l.diskadmin = 1 
UNION
select @@Servername, ''' + @database + ''', l.name as [login name], u.name as [user name],  
''dbcreator''
from [' + @database + ']..sysusers u inner join master..syslogins l
on u.sid=l.sid WHERE l.dbcreator = 1 
UNION
select @@Servername, ''' + @database + ''', l.name as [login name], u.name as [user name],  
''bulkadmin''
from [' + @database + ']..sysusers u inner join master..syslogins l
on u.sid=l.sid WHERE l.bulkadmin = 1 
'

insert into #logins_users
exec (@cmd)
fetch next from cur into @database

end 
close cur
deallocate cur

go

select * from #logins_users
order by database_name

