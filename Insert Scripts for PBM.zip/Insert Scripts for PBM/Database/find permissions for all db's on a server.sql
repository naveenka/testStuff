 --cursor
drop table #permission_report
--create #temp table
CREATE TABLE #permission_report
   (db_name varchar(50),
  username varchar(50),
  objectname varchar(100),
  objectclass varchar(50),
  permission_name varchar(50),
  state varchar(50))



declare @dbname VARCHAR(50) 



--declare cursor in order to run on every database on the server
DECLARE  c_dbnames CURSOR FOR
SELECT name 
FROM sys.databases

OPEN c_dbnames

FETCH c_dbnames INTO @dbname
WHILE @@Fetch_Status = 0
BEGIN
--Openrowset to select the appropriate columns from system catalog views
--insert result into #temp table
--repeat task on every database on server
  EXEC('INSERT INTO #permission_report(db_name,username,objectname,objectclass,permission_name,state)

SELECT '''+@dbname+''',p.name username, o.name objectname, class_desc,permission_name, state_desc
FROM ' + @dbname +'.sys.database_principals p
JOIN ' + @dbname +'.sys.database_permissions d ON d.grantee_principal_id = p.principal_id
JOIN ' + @dbname +'.sys.objects o ON o.object_id = d.major_id') 

  FETCH c_dbnames INTO @dbname
END

CLOSE c_dbnames
DEALLOCATE c_dbnames

SELECT * FROM #permission_report