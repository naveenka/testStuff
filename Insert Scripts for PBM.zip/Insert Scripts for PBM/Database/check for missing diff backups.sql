SELECT d.name, MAX(b.backup_finish_date) AS 'backup_finish_date', b.recovery_model
--SELECT *
FROM master.sys.databases d
LEFT OUTER JOIN msdb..backupset b
ON b.database_name = d.name
--AND b.type = 'L' -- tlog
AND b.type = 'D' -- diff
--AND b.type = 'I' -- full
WHERE d.recovery_model_desc = b.recovery_model COLLATE SQL_Latin1_General_CP1_CI_AS
--AND b.recovery_model != 'SIMPLE'
GROUP BY d.name, b.recovery_model
ORDER BY backup_finish_date DESC