--sp_configure 'xp_cmdshell', 1
--commdand prompt to run discovery report
--C:\Program Files\Microsoft SQL Server\110\Setup Bootstrap\SQLServer2012>setup.ex
--e /Action=RunDiscovery

--select DATEADD(dd, -2, GETDATE()), DATEADD(dd, -1, GETDATE()), DATEADD(dd, -0, GETDATE())

--exec xp_cmdshell 'SQLCMD -E -S -Q "setup.exe /Action=RunDiscovery"'

SELECT 
SERVERPROPERTY('ServerName') 'ServerName'
--,@@VERSION '@@version' 
,SERVERPROPERTY('ComputerNamePhysicalNetBIOS') 'ComputerNamePhysicalNetBIOS'
,SERVERPROPERTY('MachineName') 'MachineName'
,SERVERPROPERTY('InstanceName') 'InstanceName'
--,SERVERPROPERTY('IsClustered') 'IsClustered'
--,SERVERPROPERTY('BuildClrVersion') 'BuildClrVersion'
--,SERVERPROPERTY('Collation') 'Collation'
--,SERVERPROPERTY('CollationID') 'CollationID'
--,SERVERPROPERTY('ComparisonStyle') 'ComparisonStyle'
--,SERVERPROPERTY('ComputerNamePhysicalNetBIOS') 'ComputerNamePhysicalNetBIOS'
,SERVERPROPERTY('Edition') 'Edition'
--,SERVERPROPERTY('EditionID') 'EditionID'
--,SERVERPROPERTY('EngineEdition') 'EngineEdition'
,SERVERPROPERTY('IsFullTextInstalled') 'IsFullTextInstalled'
--,SERVERPROPERTY('IsIntegratedSecurityOnly') 'IsIntegratedSecurityOnly'
--,SERVERPROPERTY('IsSingleUser') 'IsSingleUser'
--,SERVERPROPERTY('LCID') 'LCID'
--,SERVERPROPERTY('LicenseType') 'LicenseType'
--,SERVERPROPERTY('NumLicenses') 'NumLicenses'
--,SERVERPROPERTY('ProcessID') 'ProcessID'
,SERVERPROPERTY('ProductVersion') 'ProductVersion'
,SERVERPROPERTY('ProductLevel') 'ProductLevel'
,SERVERPROPERTY('ResourceLastUpdateDateTime') 'ResourceLastUpdateDateTime'
--,SERVERPROPERTY('ResourceVersion') 'ResourceVersion'
,SERVERPROPERTY('ServerName') 'ServerName'
--,SERVERPROPERTY('SqlCharSet') 'SqlCharSet'
--,SERVERPROPERTY('SqlCharSetName') 'SqlCharSetName'
--,SERVERPROPERTY('SqlSortOrder') 'SqlSortOrder'
--,SERVERPROPERTY('SqlSortOrderName') 'SqlSortOrderName'
,SERVERPROPERTY('FilestreamShareName') 'FilestreamShareName'
,SERVERPROPERTY('FilestreamConfiguredLevel') 'FilestreamConfiguredLevel'
--,SERVERPROPERTY('FilestreamEffectiveLevel') 'FilestreamEffectiveLevel'

