USE [MDW]
GO

/****** Object:  StoredProcedure [policy].[epm_LoadPolicyHistoryDetail]    Script Date: 5/18/2015 8:38:39 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

ALTER PROCEDURE [policy].[epm_LoadPolicyHistoryDetail] @PolicyCategoryFilter VARCHAR(255)
AS
SET NOCOUNT ON;

IF @PolicyCategoryFilter = ''
SET @PolicyCategoryFilter = NULL

DECLARE @sqlcmd VARCHAR(8000), @Text NVARCHAR(255), @Remain int
SELECT @Text = CONVERT(varchar, GETDATE(), 9) + ' - Starting data integration for ' + CASE WHEN @PolicyCategoryFilter IS NULL THEN 'ALL categories' ELSE 'Category ' + @PolicyCategoryFilter END
RAISERROR (@Text, 10, 1) WITH NOWAIT;

--Insert the evaluation results.
SELECT @sqlcmd = ';WITH XMLNAMESPACES (''http://schemas.microsoft.com/sqlserver/DMF/2007/08'' AS DMF)
,cteEval AS (SELECT PH.PolicyHistoryID
	, PH.EvaluatedServer
	, PH.EvaluationDateTime
	, PH.EvaluatedPolicy
	, Res.Expr.value(''(../DMF:TargetQueryExpression)[1]'', ''nvarchar(150)'') AS EvaluatedObject
	, (CASE WHEN Res.Expr.value(''(../DMF:Result)[1]'', ''nvarchar(150)'') = ''FALSE'' AND Expr.value(''(../DMF:Exception)[1]'', ''nvarchar(max)'') = ''''
		THEN ''FAIL''
		WHEN Res.Expr.value(''(../DMF:Result)[1]'', ''nvarchar(150)'')= ''FALSE'' AND Expr.value(''(../DMF:Exception)[1]'', ''nvarchar(max)'') <> ''''
						   THEN ''ERROR''
						   ELSE ''PASS''
						END) AS PolicyResult
	, Expr.value(''(../DMF:Exception)[1]'', ''nvarchar(max)'') AS ExceptionMessage
	, CAST(Expr.value(''(../DMF:ResultDetail)[1]'', ''nvarchar(max)'')AS XML) AS ResultDetail
	, p.policy_id
	, c.name AS CategoryName
	, datename(month, EvaluationDateTime) + '' '' + datename(year, EvaluationDateTime) AS MonthYear
	, ''PowerShell EPM Framework'' AS PolicyHistorySource
	, DENSE_RANK() OVER (PARTITION BY p.policy_id, Res.Expr.value(''(../DMF:TargetQueryExpression)[1]'', ''nvarchar(150)''), PH.EvaluationDateTime ORDER BY Expr, p.policy_id, PH.PolicyHistoryID) AS [TopRank]
FROM policy.PolicyHistory AS PH
INNER JOIN msdb.dbo.syspolicy_policies AS p ON p.name = PH.EvaluatedPolicy and p.is_enabled = 1 --******
INNER JOIN msdb.dbo.syspolicy_policy_categories AS c ON p.policy_category_id = c.policy_category_id
CROSS APPLY EvaluationResults.nodes(''declare default element namespace "http://schemas.microsoft.com/sqlserver/DMF/2007/08";
	//TargetQueryExpression''
	) AS Res(Expr)
WHERE NOT EXISTS (SELECT DISTINCT PHD.PolicyHistoryID FROM policy.PolicyHistoryDetail PHD WITH(NOLOCK) WHERE PHD.PolicyHistoryID = PH.PolicyHistoryID AND PHD.ResultDetail IS NOT NULL)
	' + CASE WHEN @PolicyCategoryFilter IS NULL THEN '' ELSE 'AND c.name = ''' + @PolicyCategoryFilter + '''' END + '
	AND EvaluationResults.exist(''declare namespace DMF="http://schemas.microsoft.com/sqlserver/DMF/2007/08";
		 //DMF:EvaluationDetail'') = 1)
INSERT INTO policy.PolicyHistoryDetail (
	PolicyHistoryID
	, EvaluatedServer
	, EvaluationDateTime
	, EvaluatedPolicy
	, EvaluatedObject
	, PolicyResult
	, ExceptionMessage
	, ResultDetail
	, policy_id
	, CategoryName
	, MonthYear
	, PolicyHistorySource
)
SELECT PolicyHistoryID
	, EvaluatedServer
	, EvaluationDateTime
	, EvaluatedPolicy
	, EvaluatedObject
	, PolicyResult
	, ExceptionMessage
	, ResultDetail
	, policy_id
	, CategoryName
	, MonthYear
	, PolicyHistorySource 
FROM cteEval
WHERE cteEval.[TopRank] = 1'; -- Remove duplicates

EXEC (@sqlcmd);

SELECT @Text = CONVERT(NVARCHAR, GETDATE(), 9) + '   |- ' + CONVERT(NVARCHAR, @@ROWCOUNT) + ' rows inserted...'
RAISERROR (@Text, 10, 1) WITH NOWAIT;

SELECT @Text = CONVERT(varchar, GETDATE(), 9) + ' - Starting no target data integration'
RAISERROR (@Text, 10, 1) WITH NOWAIT;

--Insert the policies that evaluated with no target	
SELECT @sqlcmd = ';WITH XMLNAMESPACES (''http://schemas.microsoft.com/sqlserver/DMF/2007/08'' AS DMF)
INSERT INTO policy.PolicyHistoryDetail	(		
	PolicyHistoryID
	, EvaluatedServer
	, EvaluationDateTime
	, EvaluatedPolicy
	, EvaluatedObject
	, PolicyResult
	, ExceptionMessage
	, ResultDetail
	, policy_id
	, CategoryName
	, MonthYear
	, PolicyHistorySource
	)
SELECT PH.PolicyHistoryID
	, PH.EvaluatedServer
	, PH.EvaluationDateTime
	, PH.EvaluatedPolicy
	, ''No Targets Found'' AS EvaluatedObject
	, (CASE WHEN Res.Expr.value(''(../DMF:Result)[1]'', ''nvarchar(150)'')= ''FALSE'' AND Expr.value(''(../DMF:Exception)[1]'', ''nvarchar(max)'') = ''''
		   THEN ''FAIL'' 
		   WHEN Res.Expr.value(''(../DMF:Result)[1]'', ''nvarchar(150)'')= ''FALSE'' AND Expr.value(''(../DMF:Exception)[1]'', ''nvarchar(max)'')<> ''''
		   THEN ''ERROR''
		   ELSE ''PASS'' 
		END) AS PolicyResult
	, Expr.value(''(../DMF:Exception)[1]'', ''nvarchar(max)'') AS ExceptionMessage
	, NULL AS ResultDetail
	, p.policy_id
	, c.name AS CategoryName
	, datename(month, EvaluationDateTime) + '' '' + datename(year, EvaluationDateTime)  AS MonthYear
	, ''PowerShell EPM Framework''
FROM policy.PolicyHistory AS PH
INNER JOIN msdb.dbo.syspolicy_policies AS p ON p.name = PH.EvaluatedPolicy
INNER JOIN msdb.dbo.syspolicy_policy_categories AS c ON p.policy_category_id = c.policy_category_id
CROSS APPLY EvaluationResults.nodes(''declare default element namespace "http://schemas.microsoft.com/sqlserver/DMF/2007/08";
	//DMF:ServerInstance''
	) AS Res(Expr)
WHERE NOT EXISTS (SELECT DISTINCT PHD.PolicyHistoryID FROM policy.PolicyHistoryDetail PHD WITH(NOLOCK) WHERE PHD.PolicyHistoryID = PH.PolicyHistoryID AND PHD.ResultDetail IS NULL)
	' + CASE WHEN @PolicyCategoryFilter IS NULL THEN '' ELSE 'AND c.name = ''' + @PolicyCategoryFilter + '''' END + '
	AND EvaluationResults.exist(''declare namespace DMF="http://schemas.microsoft.com/sqlserver/DMF/2007/08";
	 //DMF:EvaluationDetail'') = 0
ORDER BY DENSE_RANK() OVER (ORDER BY Expr);' -- Remove duplicates

EXEC (@sqlcmd);

SELECT @Text = CONVERT(NVARCHAR, GETDATE(), 9) + '   |- ' + CONVERT(NVARCHAR, @@ROWCOUNT) + ' rows inserted...'
RAISERROR (@Text, 10, 1) WITH NOWAIT;

SELECT @Text = CONVERT(varchar, GETDATE(), 9) + ' - Starting errors data integration'
RAISERROR (@Text, 10, 1) WITH NOWAIT;

--Insert the error records
SELECT @sqlcmd = ';WITH XMLNAMESPACES (''http://schemas.microsoft.com/sqlserver/DMF/2007/08'' AS DMF)
INSERT INTO policy.EvaluationErrorHistory(		
	EvaluatedServer
	, EvaluationDateTime
	, EvaluatedPolicy
	, EvaluationResults
	)
SELECT PH.EvaluatedServer
	, PH.EvaluationDateTime
	, PH.EvaluatedPolicy
	, Expr.value(''(../DMF:Exception)[1]'', ''nvarchar(max)'') AS ExceptionMessage
FROM policy.PolicyHistory AS PH
INNER JOIN msdb.dbo.syspolicy_policies AS p ON p.name = PH.EvaluatedPolicy
INNER JOIN msdb.dbo.syspolicy_policy_categories AS c ON p.policy_category_id = c.policy_category_id
CROSS APPLY EvaluationResults.nodes(''declare default element namespace "http://schemas.microsoft.com/sqlserver/DMF/2007/08";
	//DMF:ServerInstance''
	) AS Res(Expr)
WHERE PH.PolicyHistoryID NOT IN (SELECT DISTINCT PH.PolicyHistoryID FROM policy.EvaluationErrorHistory AS PHD WITH(NOLOCK) INNER JOIN policy.PolicyHistory AS PH WITH(NOLOCK) ON PH.EvaluatedServer = PHD.EvaluatedServer AND PH.EvaluationDateTime = PHD.EvaluationDateTime AND PH.EvaluatedPolicy = PHD.EvaluatedPolicy)
	' + CASE WHEN @PolicyCategoryFilter IS NULL THEN '' ELSE 'AND c.name = ''' + @PolicyCategoryFilter + '''' END + '
	AND Expr.value(''(../DMF:Exception)[1]'', ''nvarchar(max)'') <> ''''
	--AND Res.Expr.value(''(../DMF:Result)[1]'', ''nvarchar(150)'') = ''FALSE''
ORDER BY DENSE_RANK() OVER (ORDER BY Expr);' -- Remove duplicates

EXEC (@sqlcmd);

SELECT @Text = CONVERT(NVARCHAR, GETDATE(), 9) + '   |- ' + CONVERT(NVARCHAR, @@ROWCOUNT) + ' rows inserted...'
RAISERROR (@Text, 10, 1) WITH NOWAIT;

SELECT @Text = CONVERT(varchar, GETDATE(), 9) + ' - Finished data integration for ' + CASE WHEN @PolicyCategoryFilter IS NULL THEN 'ALL categories' ELSE 'Category ' + @PolicyCategoryFilter END
RAISERROR (@Text, 10, 1) WITH NOWAIT;

GO


