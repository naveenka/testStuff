--notes on roles to grant the user group for each database
--mdw - db_datareader
--msdb - db_datareader, RSExecRole, SQLAgentOperatorRole, SQLAgentReaderRole, SQLAgentUserRole
--SQLAudit - db_datareader

use mdw;
grant execute on dbo.usp_GeneralException_Report to [DOD-IG\AM-ISD]
grant execute on dbo.usp_PermissionException_Report to [DOD-IG\AM-ISD]
grant execute on policy.epm_LoadPolicyHistoryDetail to [DOD-IG\AM-ISD]

use SQLAudit;
grant execute on usp_Counts_Table to [DOD-IG\AM-ISD]
grant execute on usp_Report_Audit_Application_Role_Password_Change to [DOD-IG\AM-ISD]
grant execute on usp_Report_Audit_Backup_Restore to [DOD-IG\AM-ISD]
grant execute on usp_Report_Audit_Change to [DOD-IG\AM-ISD]
grant execute on usp_Report_Audit_Database_Change to [DOD-IG\AM-ISD]
grant execute on usp_Report_Audit_Database_Permission_Change to [DOD-IG\AM-ISD]
grant execute on usp_Report_Audit_Database_Principal_Change to [DOD-IG\AM-ISD]
grant execute on usp_Report_Audit_Database_Role_Member_Change to [DOD-IG\AM-ISD]
grant execute on usp_Report_Audit_DBCC to [DOD-IG\AM-ISD]
grant execute on usp_Report_Audit_Failed_Login to [DOD-IG\AM-ISD]
grant execute on usp_Report_Audit_Login to [DOD-IG\AM-ISD]
grant execute on usp_Report_Audit_Login_Change_Password to [DOD-IG\AM-ISD]
grant execute on usp_Report_Audit_Logout to [DOD-IG\AM-ISD]
grant execute on usp_Report_Audit_Object_Change to [DOD-IG\AM-ISD]
grant execute on usp_Report_Audit_Object_Ownership_Change to [DOD-IG\AM-ISD]
grant execute on usp_Report_Audit_Schema_Object_Change to [DOD-IG\AM-ISD]
grant execute on usp_Report_Audit_Schema_Object_Permission_Change to [DOD-IG\AM-ISD]
grant execute on usp_Report_Audit_Server_Operation to [DOD-IG\AM-ISD]
grant execute on usp_Report_Audit_Server_Permission_Change to [DOD-IG\AM-ISD]
grant execute on usp_Report_Audit_Server_Principal_Change to [DOD-IG\AM-ISD]
grant execute on usp_Report_Audit_Server_Principal_Impersonation to [DOD-IG\AM-ISD]
grant execute on usp_Report_Audit_Server_Role_Member_Change to [DOD-IG\AM-ISD]
grant execute on usp_Report_Audit_Server_Stops_and_Stops to [DOD-IG\AM-ISD]
grant execute on usp_Report_Audit_Trace_Change to [DOD-IG\AM-ISD]

USE [master]
GO

/****** Object:  Login [DOD-IG\AM-ISD]    Script Date: 8/17/2015 10:44:47 AM ******/
--CREATE LOGIN [DOD-IG\AM-ISD] FROM WINDOWS WITH DEFAULT_DATABASE=[master], DEFAULT_LANGUAGE=[us_english]
GO

