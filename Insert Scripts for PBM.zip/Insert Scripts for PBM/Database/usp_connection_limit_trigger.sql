USE [master]
GO

/****** Object:  DdlTrigger [usp_connection_limit_trigger]    Script Date: 6/24/2015 3:48:27 PM ******/
DROP TRIGGER [usp_connection_limit_trigger] ON ALL SERVER
GO

/****** Object:  DdlTrigger [usp_connection_limit_trigger]    Script Date: 6/24/2015 3:48:27 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE TRIGGER [usp_connection_limit_trigger]
ON ALL SERVER 
FOR LOGON
AS
BEGIN
IF (SELECT COUNT(*) FROM sys.dm_exec_sessions
            WHERE is_user_process = 1 AND
                original_login_name = ORIGINAL_LOGIN()) > 500
	BEGIN
	DECLARE @savenum	INT
	DECLARE @message	NVARCHAR(200)
	SET @savenum = (SELECT COUNT(*) FROM sys.dm_exec_sessions
            WHERE is_user_process = 1 AND
                original_login_name = ORIGINAL_LOGIN())
	SET @message =  N'User: ' + ORIGINAL_LOGIN() + ' has ' + CAST(@savenum AS NVARCHAR) + ' open connections'
	RAISERROR(@message, 16, 1);
    --ROLLBACK;
	END
END


GO

SET ANSI_NULLS OFF
GO

SET QUOTED_IDENTIFIER OFF
GO

ENABLE TRIGGER [usp_connection_limit_trigger] ON ALL SERVER
GO


