--sp_who2

--KILL 51

--SELECT  DATEFROMPARTS(YEAR(DATEADD(mm, -2, GETDATE())), MONTH(DATEADD(mm, -2, GETDATE())), 1)

DELETE [MDW].[policy].[EvaluationErrorHistory]
 WHERE EvaluationDateTime < 
  DATEFROMPARTS(YEAR(DATEADD(mm, -7, GETDATE())), MONTH(DATEADD(mm, -7, GETDATE())), 1)
GO
DELETE [MDW].[policy].[PolicyHistoryDetail]
 WHERE EvaluationDateTime < 
  DATEFROMPARTS(YEAR(DATEADD(mm, -7, GETDATE())), MONTH(DATEADD(mm, -7, GETDATE())), 1)
GO
DELETE [MDW].[policy].[PolicyHistory]
  WHERE EvaluationDateTime < 
  DATEFROMPARTS(YEAR(DATEADD(mm, -7, GETDATE())), MONTH(DATEADD(mm, -7, GETDATE())), 1)
GO

--  (9 took 33:21 minutes)
--  (8 took 54:58 minutes)
--  (7 took 
