use master;
--Create linked server
DECLARE @srvr AS SYSNAME
SET @srvr = '01D019DTB\DEV'
EXEC sp_addlinkedserver @server = @srvr

--Create synonym for GeneralException table
CREATE SYNONYM GeneralException FOR
[01D019DTB\DEV].MDW.dbo.GeneralException

--Create synonym for PermissionException table
CREATE SYNONYM PermissionException FOR
[01D019DTB\DEV].MDW.dbo.PermissionException

--Create synonym for SQLServiceAccounts table
CREATE SYNONYM SQLServiceAccounts FOR
[01D019DTB\DEV].MDW.dbo.SQLServiceAccounts

--Create synonym for Config_Baseline table
CREATE SYNONYM Config_Baseline FOR
[01D019DTB\DEV].MDW.dbo.Config_Baseline

--Create synonym for TBL_SP_Configure table
CREATE SYNONYM TBL_SP_Configure FOR
[01D019DTB\DEV].MDW.dbo.TBL_SP_Configure

--Create synonym for SQLVersion table
CREATE SYNONYM SQLVersion FOR
[01D019DTB\DEV].MDW.dbo.SQLVersion

--Create synonym for DBBackups table
CREATE SYNONYM DBBackups FOR
[01D019DTB\DEV].MDW.dbo.DBBackups

CREATE SYNONYM FunctionChange FOR
[01D019DTB\DEV].MDW.dbo.SQL2_00_014900_functions

CREATE SYNONYM TriggerChange FOR
[01D019DTB\DEV].MDW.dbo.SQL2_00_015100_triggers

CREATE SYNONYM ProcedureChange FOR
[01D019DTB\DEV].MDW.dbo.SQL2_00_015200_procedures

CREATE SYNONYM DatabaseBinnChecksum FOR
[01A019DTF\MGMT].MDW.dbo.DatabaseBinnChecksum

--select * from GeneralException
--select * from PermissionException
--select * from DBBackups

--DROP synonym GeneralException
--DROP synonym PermissionException
--DROP synonym SQLServiceAccounts
--DROP synonym TBL_SP_Configure
--DROP synonym Config_Baseline
--DROP synonym SQLVersion
--DROP synonym DBBackups
--select * from sys.synonyms