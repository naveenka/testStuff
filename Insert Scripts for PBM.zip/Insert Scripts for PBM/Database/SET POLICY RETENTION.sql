SELECT * FROM msdb.dbo.syspolicy_configuration_internal
WHERE name = N'HistoryRetentionInDays'

update msdb.dbo.syspolicy_configuration_internal
set current_value = 30
WHERE name = N'HistoryRetentionInDays'