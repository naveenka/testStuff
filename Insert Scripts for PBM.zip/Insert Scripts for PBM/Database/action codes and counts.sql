use sqlaudit_anne;

select distinct action_id from dbo.temp_audit
select distinct class_type from dbo.temp_audit
select distinct object_id from dbo.temp_audit

--execute the main stored procedure
EXEC dbo.usp_Main_Import_audit_logs 'R:\Default_Trace_Audit\AuditTest2'

--5.) audit database permission change 
--[dbo].[usp_Merge_audit_database_permission_change] 
-- GRDB group
SELECT * from dbo.temp_audit WHERE action_id IN ('G','R', 'D', 'DWC', 'GWG', 'RWC', 'RWG')  --6 rows
AND class_type IN ('DB', 'SR')

--4.) audit failed login
--[dbo].[usp_Merge_audit_failed_login] 
--LGFL group
SELECT * from dbo.temp_audit WHERE action_id IN ('LGIF')  --60 rows

--1.) audit login
--[dbo].[usp_Merge_audit_login] 
--LGSD group
SELECT * from dbo.temp_audit WHERE action_id IN ('LGIS')  --109,136 rows

--2.) audit logout
--[dbo].[usp_Merge_audit_logout] 
--LO group
SELECT * from dbo.temp_audit WHERE action_id IN ('LGO')  --109,103 rows  

--6.) audit schema object permissions change 
--[dbo].[usp_Merge_audit_schema_object_permission_change]
--GRO group
SELECT * from dbo.temp_audit
WHERE action_id IN ('G', 'R', 'D', 'DWC', 'GWG', 'RWC', 'RWG')  --3 rows
AND class_type = 'U'

--8.) audit server permission change 
--[dbo].[usp_Merge_audit_server_permission_change]
-- GRSV group
SELECT * from dbo.temp_audit WHERE action_id IN ('G', 'R', 'D', 'DWC', 'GWG', 'RWC', 'RWG')  --4 rows
AND class_type = 'SR'

--7.) audit server principal change
--[dbo].[usp_Merge_audit_server_principal_change] 
--MNSP
SELECT * from dbo.temp_audit WHERE action_id IN ('CR', 'AL', 'DR')  --1 rows
AND class_type = 'SL'

--select * from sys.objects where object_id in 
--(SELECT object_id from dbo.temp_audit WHERE action_id IN ('MNSP', 'AL') )

--9.) audit login change password
--[dbo].[usp_Merge_audit_login_change_password]
--PWCG Group
SELECT * from dbo.temp_audit WHERE action_id IN ('PWC', 'PWMC', 'PWCS', 'PWR', 'PWRS', 'PWU') --PWCG Group 

--3.) audit start stop
--[dbo].[usp_Merge_audit_start_stop]
--STSV Group
SELECT * from dbo.temp_audit WHERE action_id IN ('SVCN', 'SVPD', 'SVSD', 'SVSR')  --STSV Group 

--10.) audit server role member change
--[dbo].[usp_Merge_audit_server_role_member_change]
--ADSP
SELECT * from dbo.temp_audit WHERE action_id IN ('CR', 'AL', 'DR')  --2 rows
AND class_type = 'AR'

--11.) audit database principal change 
--[dbo].[usp_Merge_audit_database_principal_change]
--MNDP Group
SELECT * from dbo.temp_audit WHERE action_id IN ('CR', 'AL', 'DR')  --4 rows
AND class_type IN ('SU', 'U')

--12.) audit database role member change
--[dbo].[usp_Merge_audit_database_role_member_change]
--ADDP Group 
SELECT * from dbo.temp_audit WHERE action_id IN ('APRL')  --8 rows

--13.) audit application role change password group
-- [dbo].[usp_Merge_audit_application_role_password_change]
--PWAR group
SELECT * from dbo.temp_audit WHERE action_id IN ('PWC')  --2 row
--*************same as above***********

--14.) audit schema object change group - MNO
--[dbo].[usp_Merge_audit_schema_object_change] 
--MNO Group
SELECT * from dbo.temp_audit WHERE action_id IN ('CR', 'AL', 'DR')  --791 rows
AND class_type = 'SC'

--15.) audit backup restore
--[dbo].[usp_Merge_audit_backup_restore] 
--BRDB group 
SELECT * from dbo.temp_audit WHERE action_id IN ('BA', 'BAL', 'RS')  --77 rows

--16.) Audit dbcc
--[dbo].[usp_Merge_DBCC]
--DBCG Group 
SELECT * from dbo.temp_audit WHERE action_id IN ('DBCC')  --63,926 rows

--17.) Audit change 
--[dbo].[usp_Merge_audit_change] 
--CNAU Group 
SELECT * from dbo.temp_audit WHERE action_id IN ('AUSC', 'AUSF')  --1 rows

--Audit schema object change - MNSO 
SELECT * from dbo.temp_audit WHERE action_id IN ('IN', 'UP', 'DL')

--18.) Audit change 
--[dbo].[usp_Merge_audit_database_change]
--MNDB Group
SELECT * from dbo.temp_audit WHERE action_id IN ('CR', 'AL', 'DR')  --9,190 rows
AND class_type IN ('U', 'P', 'V')

--22.) audit object change
--[dbo].[usp_Merge_audit_object_change] 
--MNDO, MNSO Group
SELECT * from dbo.temp_audit WHERE action_id IN ('CR', 'AL', 'DR', 'TRO')  --803 rows
AND class_type IN ('DB', 'SX', 'SC', 'SL', 'SU', 'AR')

--19.) audit trace change
--[dbo].[usp_Merge_audit_trace_change]
--'TRCG' Group
SELECT * from dbo.temp_audit WHERE action_id IN ('TASA', 'TASP', 'ALTR')  --1307 rows
AND class_type IN ('SR')

--20.) Audit impersonation
--[dbo].[usp_Merge_audit_server_principal_impersonation] 
--IMSP & IMDP Group
SELECT * from dbo.temp_audit WHERE action_id IN ('IMP')  --49 rows
AND class_type IN ('SU', 'WL', 'SL', 'US')

--21.) audit ownership change
--[dbo].[usp_Merge_audit_ownership_change]
--TOSO, TOO, TODO, TODB Group
SELECT * from dbo.temp_audit WHERE action_id IN ('TO')  --2 rows
AND class_type IN ('AG', 'EP', 'SG', 'SC', 'DB', 'OB', 'TY', 'SX') 

--23.) audit server operation
--[dbo].[usp_Merge_audit_server_operation]
-- OPSV, OPDB Group
SELECT * from dbo.temp_audit WHERE action_id IN ('VDST', 'ADBO', 'ALCN', 'ALSS', 
		  'ALST', 'VSST', 'XA', 'XU')  --6815 rows
		  
--24.) SERVER_OPERATION_GROUP
SELECT * from dbo.temp_audit WHERE action_id IN ('ADBO', 'ALCN', 'ALRS', 'ALSS', 
'ALST', 'VSST', 'XA', 'XU')

select * from dbo.temp_audit
where file_name like '%COMPLIANT_DATABASE_AUDIT%'








