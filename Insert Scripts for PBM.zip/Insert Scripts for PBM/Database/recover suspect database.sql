exec sp_resetstatus [StateService_4b47e5d4bc0c49e1aad5bacbfff3d77c]

alter database [StateService_4b47e5d4bc0c49e1aad5bacbfff3d77c] set emergency

dbcc checkdb ([StateService_4b47e5d4bc0c49e1aad5bacbfff3d77c])

alter database [StateService_4b47e5d4bc0c49e1aad5bacbfff3d77c] set single_user with rollback immediate

dbcc checkdb ([StateService_4b47e5d4bc0c49e1aad5bacbfff3d77c], REPAIR_ALLOW_DATA_LOSS)

alter database [StateService_4b47e5d4bc0c49e1aad5bacbfff3d77c] set multi_user