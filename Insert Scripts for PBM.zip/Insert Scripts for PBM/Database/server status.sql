CREATE TABLE #ServiceStatus
(
myid INT IDENTITY(1,1),
ServerName NVARCHAR(200) DEFAULT @@SERVERNAME,
InstanceName NVARCHAR(100) DEFAULT @@SERVICENAME,
ServiceName VARCHAR(100),
Status VARCHAR(50),
CheckDt DATETIME DEFAULT GETDATE()
)

INSERT #ServiceStatus (Status)
EXEC xp_servicecontrol N'QUERYSTATE',N'MSSQLServer'

UPDATE #ServiceStatus SET ServiceName = 'MSSQLServer' WHERE myid = @@identity

SELECT * FROM #ServiceStatus

--DROP TABLE #ServiceStatus