USE [MDW]
GO

/****** Object:  Table [dbo].[Config_Baseline]    Script Date: 3/12/2015 1:39:25 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Config_Baseline](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Config_ID] [int] NULL,
	[Server] [varchar](100) NULL,
	[Instance] [varchar](100) NULL,
	[Config_Value] [int] NULL,
	[Config_Run] [int] NULL,
	[DateSet] [datetime] NULL CONSTRAINT [DF_Config_Baseline_DateSet]  DEFAULT (getdate())
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[DBBackups]    Script Date: 3/12/2015 1:39:25 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[DBBackups](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Server] [varchar](100) NULL,
	[Instance] [varchar](100) NULL,
	[DBName] [varchar](100) NULL,
	[RecoveryModel] [varchar](10) NULL,
	[LastFull] [datetime] NULL,
	[LastDiff] [datetime] NULL,
	[LastTran] [datetime] NULL,
	[FullDeviceName] [varchar](100) NULL,
	[DiffDeviceName] [varchar](100) NULL,
	[TranDeviceName] [varchar](100) NULL,
	[CreateDate] [datetime] NULL CONSTRAINT [DF_DBBackups_CreateDate]  DEFAULT (getdate())
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[GeneralException]    Script Date: 3/12/2015 1:39:25 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[GeneralException](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[STIGItem] [int] NULL,
	[Server] [varchar](400) NULL,
	[Instance] [varchar](400) NULL,
	[ExceptionValue] [varchar](400) NULL,
	[Comments] [varchar](2000) NULL,
	[ModifiedBy] [varchar](400) NULL,
	[CreateDate] [date] NULL CONSTRAINT [DF_GeneralException_CreateDate]  DEFAULT (getdate())
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[GeneralException_Save]    Script Date: 3/12/2015 1:39:25 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[GeneralException_Save](
	[ID] [int] NOT NULL,
	[STIGItem] [int] NULL,
	[Server] [varchar](400) NULL,
	[Instance] [varchar](400) NULL,
	[ExceptionValue] [varchar](400) NULL,
	[Comments] [varchar](2000) NULL,
	[ModifiedBy] [varchar](400) NULL,
	[CreateDate] [date] NULL CONSTRAINT [DF_GeneralException_Save_CreateDate]  DEFAULT (getdate())
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[PermissionException]    Script Date: 3/12/2015 1:39:25 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[PermissionException](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[STIGItem] [int] NULL,
	[Server] [varchar](500) NULL,
	[Instance] [varchar](500) NULL,
	[PermissionValue] [varchar](1000) NULL,
	[GranteePersonName] [varchar](1000) NULL,
	[Comments] [varchar](2000) NULL,
	[ModifiedBy] [varchar](400) NULL,
	[CreateDate] [date] NULL CONSTRAINT [DF_PermissionException_CreateDate]  DEFAULT (getdate())
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[PermissionException_Save]    Script Date: 3/12/2015 1:39:25 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[PermissionException_Save](
	[ID] [int] NOT NULL,
	[STIGItem] [int] NULL,
	[Server] [varchar](500) NULL,
	[Instance] [varchar](500) NULL,
	[PermissionValue] [varchar](1000) NULL,
	[GranteePersonName] [varchar](1000) NULL,
	[Comments] [varchar](2000) NULL,
	[ModifiedBy] [varchar](400) NULL,
	[CreateDate] [date] NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[SQLServiceAccounts]    Script Date: 3/12/2015 1:39:25 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[SQLServiceAccounts](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[ServerName] [varchar](100) NULL,
	[InstanceName] [varchar](100) NULL,
	[ServiceAcctType] [int] NULL,
	[ServiceAcctDomain] [varchar](100) NULL,
	[ServiceAcctName] [varchar](100) NULL,
	[DateAdded] [date] NULL CONSTRAINT [DF_SQLServiceAccounts_DateAdded]  DEFAULT (getdate())
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[SQLServiceAcctType]    Script Date: 3/12/2015 1:39:25 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[SQLServiceAcctType](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[SQLServiceType] [varchar](100) NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[SQLVersion]    Script Date: 3/12/2015 1:39:25 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[SQLVersion](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[SQLName] [varchar](50) NULL,
	[SQLVersion] [int] NULL,
	[SQLMinorVersion] [int] NULL,
	[SQLBuild] [int] NULL,
	[SQLSPLevel] [int] NULL,
	[SQLCULevel] [int] NULL,
	[DateModified] [datetime] NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[STIGItems]    Script Date: 3/12/2015 1:39:25 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[STIGItems](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[STIGName] [varchar](100) NULL,
	[CreateDate] [date] NULL CONSTRAINT [DF_STIGItems_CreateDate]  DEFAULT (getdate())
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

/****** Object:  Table [dbo].[TBL_SP_Configure]    Script Date: 3/12/2015 1:39:25 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[TBL_SP_Configure](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[ConfigName] [nvarchar](35) NULL,
	[ConfigMin] [int] NULL,
	[ConfigMax] [int] NULL
) ON [PRIMARY]

GO

/****** Object:  Table [policy].[EvaluationErrorHistory]    Script Date: 3/12/2015 1:39:25 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [policy].[EvaluationErrorHistory](
	[ErrorHistoryID] [int] IDENTITY(1,1) NOT NULL,
	[EvaluatedServer] [nvarchar](50) NULL,
	[EvaluationDateTime] [datetime] NULL CONSTRAINT [DF_EvaluationErrorHistory_EvaluationDateTime]  DEFAULT (getdate()),
	[EvaluatedPolicy] [nvarchar](128) NULL,
	[EvaluationResults] [nvarchar](max) NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

/****** Object:  Table [policy].[EvaluationErrorHistory_old]    Script Date: 3/12/2015 1:39:25 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [policy].[EvaluationErrorHistory_old](
	[ErrorHistoryID] [int] IDENTITY(1,1) NOT NULL,
	[EvaluatedServer] [nvarchar](50) NULL,
	[EvaluationDateTime] [datetime] NULL,
	[EvaluatedPolicy] [nvarchar](128) NULL,
	[EvaluationResults] [nvarchar](max) NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

/****** Object:  Table [policy].[PolicyHistory]    Script Date: 3/12/2015 1:39:25 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [policy].[PolicyHistory](
	[PolicyHistoryID] [int] IDENTITY(1,1) NOT NULL,
	[EvaluatedServer] [nvarchar](50) NULL,
	[EvaluationDateTime] [datetime] NULL CONSTRAINT [DF_PolicyHistory_EvaluationDateTime]  DEFAULT (getdate()),
	[EvaluatedPolicy] [nvarchar](128) NULL,
	[EvaluationResults] [xml] NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

/****** Object:  Table [policy].[PolicyHistoryDetail]    Script Date: 3/12/2015 1:39:25 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [policy].[PolicyHistoryDetail](
	[PolicyHistoryDetailID] [int] IDENTITY(1,1) NOT NULL,
	[PolicyHistoryID] [int] NULL,
	[EvaluatedServer] [nvarchar](128) NULL,
	[EvaluationDateTime] [datetime] NULL,
	[MonthYear] [nvarchar](14) NULL,
	[EvaluatedPolicy] [nvarchar](128) NULL,
	[policy_id] [int] NULL,
	[CategoryName] [nvarchar](128) NULL,
	[EvaluatedObject] [nvarchar](256) NULL,
	[PolicyResult] [nvarchar](5) NOT NULL,
	[ExceptionMessage] [nvarchar](max) NULL,
	[ResultDetail] [xml] NULL,
	[PolicyHistorySource] [nvarchar](50) NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

