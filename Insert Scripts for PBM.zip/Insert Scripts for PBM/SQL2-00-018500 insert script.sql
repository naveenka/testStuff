--INSERT INTO master.dbo.GeneralException
--           ([STIGItem]
--           ,[Server]
--           ,[Instance]
--           ,[ExceptionValue]
--           ,[Comments]
--           ,[ModifiedBy]
--           ,[CreateDate])

Select 92, @@SERVERNAME, @@SERVICENAME, name, 'Not a Shared Account',SUSER_SNAME(), GETDATE()
--Select 92, @@SERVERNAME, @@SERVICENAME, name, 'Is a Shared Account - but not accessible to users',SUSER_SNAME(), GETDATE()
--Select * 
from sys.sysusers
where uid > 16000
and name not in 
('db_owner', 'db_accessadmin',
'db_securityadmin', 'db_ddladmin',
'db_backupoperator', 'db_datareader',
'db_datawriter', 'db_denydatareader',
'db_denydatawriter')
AND name COLLATE Latin1_General_CI_AS_KS_WS NOT IN (SELECT ExceptionValue FROM master.dbo.GeneralException
	WHERE STIGItem = 92
	AND [Server] = @@SERVERNAME
	AND Instance = @@SERVICENAME)