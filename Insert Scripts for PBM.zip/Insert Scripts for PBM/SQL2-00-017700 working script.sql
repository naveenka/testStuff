   DECLARE @SaveRowCount		INT
	
	SELECT  bsfull.[server_name] ,
			bsfull.[database_name] ,
			bsfull.[recovery_model] ,
            bsfull.[backup_finish_date] AS [last_full_backup] ,
            bsdiff.[backup_finish_date] AS [last_diff_backup] ,
            bstlog.[backup_finish_date] AS [last_tran_backup] ,
            DATEDIFF(dd, bsfull.[backup_finish_date], CURRENT_TIMESTAMP) AS [days_since_full_backup] ,
            DATEDIFF(dd, bsdiff.[backup_finish_date], CURRENT_TIMESTAMP) AS [days_since_diff_backup] ,
            DATEDIFF(hh, bstlog.[backup_finish_date], CURRENT_TIMESTAMP) AS [hours_since_tranlog_backup] ,
            ( SELECT    TOP 1 [physical_device_name]
              FROM      [msdb]..[backupmediafamily] bmf
              WHERE     bmf.[media_set_id] = bsfull.[media_set_id]
            ) AS [full_backup_location] ,
            ( SELECT    TOP 1 [physical_device_name]
              FROM      [msdb]..[backupmediafamily] bmf
              WHERE     bmf.[media_set_id] = bsdiff.[media_set_id]
            ) AS [diff_backup_location] ,
            ( SELECT    TOP 1 [physical_device_name]
              FROM      [msdb]..[backupmediafamily] bmf
              WHERE     bmf.[media_set_id] = bstlog.[media_set_id]
            ) AS [tlog_backup_location]
	INTO #MostRecentBackupStatus
    FROM    [msdb]..[backupset] AS bsfull
            LEFT JOIN [msdb]..[backupset] AS bstlog ON bstlog.[database_name] = bsfull.[database_name]
                                                       AND bstlog.[server_name] = bsfull.[server_name]
                                                       AND bstlog.[type] = 'L'
                                                       AND bstlog.[backup_finish_date] = ( (SELECT  MAX([backup_finish_date])
                                                                                            FROM    [msdb]..[backupset] b2
                                                                                            WHERE   b2.[database_name] = bsfull.[database_name]
                                                                                                    AND b2.[server_name] = bsfull.[server_name]
                                                                                                    AND b2.[type] = 'L') )
            LEFT JOIN [msdb]..[backupset] AS bsdiff ON bsdiff.[database_name] = bsfull.[database_name]
                                                       AND bsdiff.[server_name] = bsfull.[server_name]
                                                       AND bsdiff.[type] = 'I'
                                                       AND bsdiff.[backup_finish_date] = ( (SELECT  MAX([backup_finish_date])
                                                                                            FROM    [msdb]..[backupset] b2
                                                                                            WHERE   b2.[database_name] = bsfull.[database_name]
                                                                                                    AND b2.[server_name] = bsfull.[server_name]
                                                                                                    AND b2.[type] = N'I') )
	WHERE   bsfull.[type] = N'D'
            AND bsfull.[backup_finish_date] = ( (SELECT MAX([backup_finish_date])
                                                 FROM   [msdb]..[backupset] b2
                                                 WHERE  b2.[database_name] = bsfull.[database_name]
                                                        AND b2.[server_name] = bsfull.[server_name]
                                                        AND b2.[type] = N'D') )
            AND EXISTS ( SELECT [name]
                         FROM   [master].[sys].[databases]
                         WHERE  [name] = bsfull.[database_name] )
            --AND bsfull.[database_name] NOT IN (N'master', N'tempdb', N'model', N'msdb')
			AND bsfull.[database_name] NOT IN (N'tempdb')
			AND bsfull.[server_name] = @@SERVERNAME

select * from #MostRecentBackupStatus
order by server_name, database_name, recovery_model

select *
  FROM [DBBackups]
  WHERE server = '01D019DTA\CRM4'
  order by server, instance, dbname


--can't use merge on remote target
UPDATE master.dbo.dbbackups SET
	[RecoveryModel] = SOURCE.[recovery_model],
    [LastFull] = SOURCE.[last_full_backup] ,
    [LastDiff] = SOURCE.[last_diff_backup] ,
    [LastTran] = SOURCE.[last_tran_backup] ,
    [FullDeviceName] = SOURCE.[full_backup_location] ,
    [DiffDeviceName] = SOURCE.[diff_backup_location] ,
    [TranDeviceName] = SOURCE.[tlog_backup_location] 
FROM master.dbo.dbbackups AS TARGET
JOIN #MostRecentBackupStatus AS SOURCE
ON TARGET.[Server] = SOURCE.[server_name]
AND TARGET.[DBName] = SOURCE.[database_name]
--AND TARGET.[RecoveryModel] = SOURCE.[recovery_model]

--select * from sys.synonyms

SET @SaveRowCount = @@rowcount
 select @SaveRowCount as 'before insert'
--INSERT 
INSERT INTO master.dbo.dbbackups (Server, Instance, DBName, RecoveryModel, LastFull, LastDiff, LastTran, FullDeviceName, DiffDeviceName, TranDeviceName, CreateDate)
SELECT SOURCE.[server_name], @@SERVICENAME, SOURCE.[database_name], SOURCE.[recovery_model], 
		SOURCE.[last_full_backup], SOURCE.[last_diff_backup], SOURCE.[last_tran_backup], 
		SOURCE.[full_backup_location], SOURCE.[diff_backup_location], SOURCE.[tlog_backup_location], GETDATE()
FROM #MostRecentBackupStatus AS SOURCE
WHERE NOT EXISTS (SELECT * FROM master.dbo.dbbackups AS TARGET
--RIGHT JOIN #MostRecentBackupStatus AS SOURCE
WHERE TARGET.[Server] = SOURCE.[server_name]
AND TARGET.[DBName] = SOURCE.[database_name])
--AND TARGET.[RecoveryModel] = SOURCE.[recovery_model])

SET @SaveRowCount = @SaveRowCount + @@rowcount

 select @SaveRowCount as 'after insert'

 select *
  FROM [DBBackups]
  WHERE server = '01D019DTA\CRM4'
  order by server, instance, dbname


--DELETE
DELETE [MDW].[dbo].[DBBackups]
--select *
FROM  [MDW].[dbo].[DBBackups] AS d
LEFT JOIN sys.databases AS b
ON d.[DBName] = b.[name]
--AND d.[RecoveryModel] = b.[recovery_model_desc] COLLATE SQL_Latin1_General_CP1_CI_AS
WHERE b.[name] IS NULL
--AND d.[DBName] NOT IN ('master', 'tempdb', 'model', 'msdb')
AND d.[Server] = @@Servername

SET @SaveRowCount = @SaveRowCount + @@rowcount

SELECT @SaveRowCount

--select *
--  FROM [MDW].[dbo].[DBBackups]
--  WHERE server = '01D019DTA\CRM4'
--  order by server, instance, dbname

select * from #MostRecentBackupStatus

DROP TABLE #MostRecentBackupStatus






 