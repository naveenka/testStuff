use master;
EXEC sp_MSforeachdb '
--INSERT INTO master.dbo.GeneralException
--           ([STIGItem]
--           ,[Server]
--           ,[Instance]
--           ,[ExceptionValue]
--           ,[Comments]
--           ,[ModifiedBy]
--           ,[CreateDate])

--Select 95, @@SERVERNAME, @@SERVICENAME, principal_id, '''',SUSER_SNAME(), GETDATE()
SELECT ''?'', *
  FROM [?].sys.symmetric_keys 
 WHERE key_algorithm NOT IN (''D3'',''A1'',''A2'',''A3'')
 AND name  COLLATE SQL_Latin1_General_CP1_CI_AS NOT IN (SELECT ExceptionValue FROM master.dbo.GeneralException
	WHERE STIGItem = 95
	AND [Server] = @@SERVERNAME
	AND Instance = @@SERVICENAME)  '


