SELECT COUNT(*) FROM sys.server_triggers
WHERE name COLLATE Latin1_General_CI_AS_KS_WS = 'usp_connection_limit_trigger'
AND is_disabled = 0