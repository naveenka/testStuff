EXEC sp_MSforeachdb '
USE [?]
--INSERT INTO master.dbo.GeneralException
--           ([STIGItem]
--           ,[Server]
--           ,[Instance]
--           ,[ExceptionValue]
--           ,[Comments]
--           ,[ModifiedBy]
--           ,[CreateDate])
Select 106, @@SERVERNAME, @@SERVICENAME, ''?'', SUSER_SNAME(), GETDATE()
--SELECT *
FROM sys.symmetric_keys s, sys.key_encryptions k
WHERE s.symmetric_key_id = k.key_id
AND k.crypt_type IN (''ESKP'', ''ESKS'')
AND s.principal_id <> 1
AND ''?'' NOT IN (SELECT ExceptionValue FROM master.dbo.GeneralException
	WHERE STIGItem = 106
	AND [Server] = @@SERVERNAME
	AND Instance = @@SERVICENAME)'