SET NOCOUNT ON

DECLARE @SSASService  	NVARCHAR(60)
DECLARE @Instance	  	NVARCHAR(60)
DECLARE @WorkingNm		NVARCHAR(60)
DECLARE @RKey			NVARCHAR(60)
DECLARE @RtrnCd			TINYINT

SET @RtrnCd = 0

SET @Instance = @@SERVICENAME

-- we get the instance aware service accounts below
IF @Instance = 'MSSQLSERVER' 
BEGIN
BEGIN TRY

SET @WorkingNm = 'MSOLAP' 	
SET @RKey = 'SYSTEM\ControlSet001\Services\' + @WorkingNm + '\'	
			
-- get SSAS account
EXEC xp_instance_regread @root_key  	= 'HKEY_LOCAL_MACHINE',
				@key   		= @RKey,
				@valuename  	= 'ObjectName',
				@value   	= @SSASService output
END TRY
BEGIN CATCH
	SET @SSASService = NULL
END CATCH
--SELECT @SSASService as 'SSASService'

END

ELSE
-- get this named instance services
BEGIN
BEGIN TRY

SET @WorkingNm = 'MSOLAP$' + @Instance	
SET @RKey = 'SYSTEM\ControlSet001\Services\' + @WorkingNm + '\'	

-- get SSAS account
EXEC xp_instance_regread @root_key  	= 'HKEY_LOCAL_MACHINE',
				@key   		= @RKey,
				@valuename  	= 'ObjectName',
				@value   	= @SSASService output
END TRY
BEGIN CATCH
	SET @SSASService = NULL
END CATCH
--SELECT @SSASService as 'SSASService'

END

SELECT (CASE WHEN @SSASService IS NULL THEN 0 ELSE 
(CASE WHEN (SELECT 1 FROM master.dbo.GeneralException
	WHERE STIGItem = 115
	AND [Server] = @@SERVERNAME
	AND Instance = @@SERVICENAME) IS NOT NULL THEN 0 ELSE 1 END) END) 

/*
 INSERT INTO master.dbo.GeneralException
           ([STIGItem]
           ,[Server]
           ,[Instance]
           ,[ExceptionValue]
           ,[Comments]
           ,[ModifiedBy]
           ,[CreateDate])
Select 113, @@SERVERNAME, @@SERVICENAME, 'SSAS', '',SUSER_SNAME(), GETDATE()
*/