 --INSERT INTO master.dbo.GeneralException
 --          ([STIGItem]
 --          ,[Server]
 --          ,[Instance]
 --          ,[ExceptionValue]
 --          ,[Comments]
 --          ,[ModifiedBy]
 --          ,[CreateDate])
--Select 132, @@SERVERNAME, @@SERVICENAME, name, '',SUSER_SNAME(), GETDATE()
----SELECT *
--FROM [master].sys.databases as s
--WHERE is_encrypted = 0 
--AND name NOT IN (SELECT ExceptionValue FROM master.dbo.GeneralException
--	WHERE STIGItem = 132
--	AND [Server] = @@SERVERNAME
--	AND Instance = @@SERVICENAME) 


EXEC sp_MSforeachdb
'
--DECLARE @nCount integer;
 
--SELECT @nCount = Count(*)
--  FROM [?].sys.symmetric_keys
--WHERE key_algorithm NOT IN (''D3'',''A1'',''A2'',''A3'');

--IF @nCount > 0
--INSERT INTO master.dbo.GeneralException
 --          ([STIGItem]
 --          ,[Server]
 --          ,[Instance]
 --          ,[ExceptionValue]
 --          ,[Comments]
 --          ,[ModifiedBy]
 --          ,[CreateDate])
Select 132, @@SERVERNAME, @@SERVICENAME, ''?'', name, SUSER_SNAME(), GETDATE()
    FROM [?].sys.symmetric_keys
    WHERE key_algorithm NOT IN (''D3'',''A1'',''A2'',''A3'')
	AND ''?'' NOT IN (SELECT ExceptionValue FROM master.dbo.GeneralException
	WHERE STIGItem = 132
	AND [Server] = @@SERVERNAME
	AND Instance = @@SERVICENAME) 
' ;




