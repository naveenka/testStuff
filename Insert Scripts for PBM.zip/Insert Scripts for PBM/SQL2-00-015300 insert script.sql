CREATE TABLE [dbo].[#temp_SP_Configure](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[ConfigName] [nvarchar](35) NULL,
	[ConfigMin] [int] NULL,
	[ConfigMax] [int] NULL,
	[ConfigValue] [int] NULL,
	[ConfigRun] [int] NULL)

INSERT INTO  [dbo].[#temp_SP_Configure]([ConfigName],
	[ConfigMin], [ConfigMax], [ConfigValue], [ConfigRun])
EXEC sp_configure

IF (SELECT COUNT(*) FROM master.dbo.Config_Baseline
WHERE [Server] = @@SERVERNAME
AND Instance = @@SERVICENAME) = 0
BEGIN
INSERT INTO master.dbo.Config_Baseline
           ([Config_ID], [Server], [Instance], [Config_Value]
           , [Config_Run])
SELECT sp.ID, @@SERVERNAME, @@SERVICENAME, t.ConfigValue, t.ConfigRun
FROM #temp_SP_Configure AS t JOIN master.dbo.TBL_SP_Configure AS SP
ON t.ID = SP.ID
END

UPDATE master.dbo.Config_Baseline 
SET Config_Value = t.ConfigValue,
Config_Run = t.ConfigRun
FROM master.dbo.Config_Baseline JOIN
#temp_SP_Configure AS t ON Config_ID = t.ID
AND [Server] = @@SERVERNAME
AND Instance = @@SERVICENAME
WHERE Config_Value <> t.ConfigValue
OR Config_Run <> t.ConfigRun

SELECT * FROM master.dbo.Config_Baseline AS sp
JOIN #temp_SP_Configure AS t ON sp.Config_ID = t.ID
AND [Server] = @@SERVERNAME
AND Instance = @@SERVICENAME
WHERE sp.Config_Value <> t.ConfigValue
OR sp.Config_Run <> t.ConfigRun

drop table #temp_SP_Configure

