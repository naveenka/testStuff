EXEC sp_configure 'show advanced options', 1
RECONFIGURE
EXEC sp_configure 'xp_cmdshell', 1
RECONFIGURE

--EXEC xp_cmdshell 'del /f R:\Audit\FCIV\dbsha.xml /q'

DECLARE @BinnPath VARCHAR(450)
DECLARE @SQL VARCHAR (650)
DECLARE @CntOf INT

IF SUBSTRING(@@version, 24, 2) = 12
BEGIN
SET @BinnPath = 'C:\Program Files\Microsoft SQL Server\MSSQL11.' + CAST(@@SERVICENAME AS VARCHAR) + '\MSSQL\Binn'
END
ELSE
BEGIN
SET @BinnPath = 'C:\Program Files\Microsoft SQL Server\MSSQL10_50.' + CAST(@@SERVICENAME AS VARCHAR) + '\MSSQL\Binn'
END

--SET @SQL = 'R:\Audit\FCIV\fciv.exe "' + @BinnPath + '" -r -exc exceptions.txt -sha1 -xml R:\Audit\FCIV\dbsha.xml'
SET @SQL = 'R:\Audit\FCIV\fciv.exe "' + @BinnPath + '" -r -sha1 -xml R:\Audit\FCIV\dbsha.xml >nul 2>&1'
--print @SQL
EXEC xp_cmdshell @SQL; 

EXEC sp_configure 'xp_cmdshell', 0
RECONFIGURE

--Import the file
CREATE TABLE ##XMLwithOpenXML
(
Id INT IDENTITY PRIMARY KEY,
XMLData XML,
LoadedDateTime DATETIME
)

INSERT INTO ##XMLwithOpenXML(XMLData, LoadedDateTime)
SELECT CONVERT(XML, BulkColumn) AS BulkColumn, GETDATE() 
FROM OPENROWSET(BULK 'R:\Audit\FCIV\dbsha.xml', SINGLE_BLOB) AS x;

--SELECT * FROM ##XMLwithOpenXML

---extract data
DECLARE @XML AS XML, @hDoc AS INT

SELECT @XML = XMLData FROM ##XMLwithOpenXML

EXEC sp_xml_preparedocument @hDoc OUTPUT, @XML

SELECT FilePath, Chksum
INTO ##XMLtoTABLE
FROM OPENXML(@hDoc, 'FCIV/FILE_ENTRY')
WITH 
(
FilePath [varchar](350) 'name',
Chksum [varchar](100) 'SHA1'
)

EXEC sp_xml_removedocument @hDoc

SET @CntOf = (SELECT MAX(CountOf) FROM dbo.DatabaseBinnChecksum 
WHERE Servername = @@SERVERNAME AND Instancename = @@SERVICENAME)

IF @CntOf IS NULL SET @CntOf = 0

--INSERT INTO dbo.DatabaseBinnChecksum 
--	([Servername]
--    ,[Instancename]
--    ,[BinnPath]
--    ,[FilePath]
--    ,[Chksum]
--    ,[CountOf]
--    ,[ModifiedBy]
--    ,[ModifiedDate])
SELECT @@SERVERNAME AS 'Servername', @@SERVICENAME AS 'Instancename', @BinnPath AS 'BinnPath', 
FilePath, Chksum, @CntOf + 1, SUSER_SNAME() AS 'ModifiedBy', GETDATE() AS 'ModifiedDate' 
FROM ##XMLtoTABLE AS x 
WHERE NOT EXISTS (SELECT * FROM dbo.DatabaseBinnChecksum AS d
	WHERE d.Servername = @@SERVERNAME
	AND d.Instancename = @@SERVICENAME
	AND d.BinnPath = @BinnPath
	AND d.FilePath = x.FilePath
	AND d.Chksum = x.chksum
	AND d.CountOf = @CntOf)

DROP TABLE ##XMLwithOpenXML
DROP TABLE ##XMLtoTABLE


