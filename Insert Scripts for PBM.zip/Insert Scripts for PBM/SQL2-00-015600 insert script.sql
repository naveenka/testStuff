--INSERT INTO master.dbo.GeneralException
--           ([STIGItem]
--           ,[Server]
--           ,[Instance]
--           ,[ExceptionValue]
--           ,[Comments]
--           ,[ModifiedBy]
--           ,[CreateDate])

Select DISTINCT 84, @@SERVERNAME, @@SERVICENAME, name + ' - ' + SUSER_SNAME(owner_sid), 'Service account need to own database for Share Point',SUSER_SNAME(), GETDATE()
--SELECT *
FROM sys.databases
WHERE SUSER_SNAME(owner_sid) NOT IN (SUSER_SNAME(0x01)) 
AND name + ' - ' + SUSER_SNAME(owner_sid) COLLATE Latin1_General_CI_AS_KS_WS NOT IN (SELECT ExceptionValue FROM master.dbo.GeneralException
	WHERE STIGItem = 84
	AND [Server] = @@SERVERNAME
	AND Instance = @@SERVICENAME) 

/*
use scout1;
exec sp_changedbowner 'ISDDBA'
*/
