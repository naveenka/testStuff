
--INSERT INTO master.dbo.GeneralException
--           ([STIGItem]
--           ,[Server]
--           ,[Instance]
--           ,[ExceptionValue]
--           ,[Comments]
--           ,[ModifiedBy]
--		   ,[CreateDate])

Select DISTINCT 122, @@SERVERNAME, @@SERVICENAME, 'KERBEROS', '',SUSER_SNAME(), GETDATE()
--SELECT * 
FROM sys.dm_exec_connections
WHERE encrypt_option = 'FALSE'
AND 'KERBEROS' NOT IN (SELECT ExceptionValue FROM master.dbo.GeneralException
	WHERE STIGItem = 122
	AND [Server] = @@SERVERNAME
	AND Instance = @@SERVICENAME) 