SET NOCOUNT ON

DECLARE @SSISService  	NVARCHAR(60)
DECLARE @Instance	  	NVARCHAR(60)
DECLARE @WorkingNm		NVARCHAR(60)
DECLARE @RKey			NVARCHAR(60)
DECLARE @RtrnCd			TINYINT

SET @RtrnCd = 0

SET @Instance = @@SERVICENAME

-- get ssis service account
BEGIN TRY
EXEC xp_instance_regread @root_key  	= 'HKEY_LOCAL_MACHINE',
				@key   		= 'SYSTEM\ControlSet001\Services\MsDtsServer110',
				@valuename  	= 'ObjectName',
				@value   	= @SSISService output
END TRY
BEGIN CATCH
	SET @SSISService = NULL
END CATCH
--SELECT @SSISService as 'SSISService'

SELECT (CASE WHEN @SSISService IS NULL THEN 0 ELSE 
(CASE WHEN (SELECT 1 FROM master.dbo.GeneralException
	WHERE STIGItem = 114
	AND [Server] = @@SERVERNAME
	AND Instance = @@SERVICENAME) IS NOT NULL THEN 0 ELSE 1 END) END)


/*
 INSERT INTO master.dbo.GeneralException
           ([STIGItem]
           ,[Server]
           ,[Instance]
           ,[ExceptionValue]
           ,[Comments]
           ,[ModifiedBy]
           ,[CreateDate])
Select 114, @@SERVERNAME, @@SERVICENAME, 'SSIS', 'Disabled 23July2015 will be removed',SUSER_SNAME(), GETDATE()
*/