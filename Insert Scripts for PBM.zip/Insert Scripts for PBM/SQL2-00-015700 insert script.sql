
--INSERT INTO master.dbo.GeneralException
--           ([STIGItem]
--           ,[Server]
--           ,[Instance]
--           ,[ExceptionValue]
--           ,[Comments]
--           ,[ModifiedBy]
--           ,[CreateDate])
Select 142, @@SERVERNAME, @@SERVICENAME, SERVERPROPERTY('ProductVersion'), 'No Max Audit File Size Required',SUSER_SNAME(), GETDATE()
--select * 
FROM master.dbo.SQLVersion
WHERE SQLName = SUBSTRING(@@version, 1, 25)
AND SERVERPROPERTY('ProductVersion') != CAST(SQLVersion AS VARCHAR) + '.' + CAST(SQLMinorVersion AS VARCHAR) + '.' + CAST(SQLBuild AS VARCHAR) + '.0'
AND SERVERPROPERTY('ProductVersion') NOT IN (SELECT ExceptionValue FROM master.dbo.GeneralException
	WHERE STIGItem = 142
	AND [Server] = @@SERVERNAME
	AND Instance = @@SERVICENAME)
