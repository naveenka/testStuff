USE [master]
GO

/****** Object:  ServerRole [ServerRole-Connect]    Script Date: 9/28/2015 9:08:07 AM
CREATE SERVER ROLE [ServerRole-opsmgrsaa]
GO
GRANT VIEW ANY DATABASE TO [ServerRole-opsmgrsaa]
GO
GRANT VIEW ANY DEFINITION TO [ServerRole-opsmgrsaa]
GO
GRANT VIEW SERVER STATE TO [ServerRole-opsmgrsaa]
GO
*/

SELECT 'ALTER SERVER ROLE [ServerRole-opsmgrsaa] ADD MEMBER [' + name + '];'
FROM 
       sys.server_permissions what 
       INNER JOIN sys.server_principals who
              ON who.principal_id = what.grantee_principal_id
WHERE
       what.permission_name = 'VIEW ANY DATABASE'
AND    who.name NOT LIKE '##MS%##'
AND    who.principal_id <> 1 -- Principal 1 is [sa], which may have been renamed
AND    who.type_desc <> 'SERVER_ROLE'
UNION
SELECT 'ALTER SERVER ROLE [ServerRole-opsmgrsaa] ADD MEMBER [' + name + '];'
FROM 
       sys.server_permissions what 
       INNER JOIN sys.server_principals who
              ON who.principal_id = what.grantee_principal_id
WHERE
       what.permission_name = 'VIEW ANY DEFINITION'
AND    who.name NOT LIKE '##MS%##'
AND    who.principal_id <> 1 -- Principal 1 is [sa], which may have been renamed
AND    who.type_desc <> 'SERVER_ROLE'
UNION
SELECT 'ALTER SERVER ROLE [ServerRole-opsmgrsaa] ADD MEMBER [' + name + '];'
FROM 
       sys.server_permissions what 
       INNER JOIN sys.server_principals who
              ON who.principal_id = what.grantee_principal_id
WHERE
       what.permission_name = 'VIEW SERVER STATE'
AND    who.name NOT LIKE '##MS%##'
AND    who.principal_id <> 1 -- Principal 1 is [sa], which may have been renamed
AND    who.type_desc <> 'SERVER_ROLE'


--Remove users from VIEW ANY DATABASE SQL
SELECT 'REVOKE VIEW ANY DATABASE FROM  [' + name + '];'
FROM 
       sys.server_permissions what 
       INNER JOIN sys.server_principals who
              ON who.principal_id = what.grantee_principal_id
WHERE
       what.permission_name = 'VIEW ANY DATABASE'
AND    who.name NOT LIKE '##MS%##'
AND    who.principal_id <> 1 -- Principal 1 is [sa], which may have been renamed
AND    who.type_desc <> 'SERVER_ROLE'
UNION
--Remove users from VIEW ANY DEFINITION SQL
SELECT 'REVOKE VIEW ANY DEFINITION FROM  [' + name + '];'
FROM 
       sys.server_permissions what 
       INNER JOIN sys.server_principals who
              ON who.principal_id = what.grantee_principal_id
WHERE
       what.permission_name = 'VIEW ANY DEFINITION'
AND    who.name NOT LIKE '##MS%##'
AND    who.principal_id <> 1 -- Principal 1 is [sa], which may have been renamed
AND    who.type_desc <> 'SERVER_ROLE'
UNION
--Remove users from VIEW SERVER STATE SQL
SELECT 'REVOKE VIEW SERVER STATE FROM  [' + name + '];'
FROM 
       sys.server_permissions what 
       INNER JOIN sys.server_principals who
              ON who.principal_id = what.grantee_principal_id
WHERE
       what.permission_name = 'VIEW SERVER STATE'
AND    who.name NOT LIKE '##MS%##'
AND    who.principal_id <> 1 -- Principal 1 is [sa], which may have been renamed
AND    who.type_desc <> 'SERVER_ROLE'
GO

USE master;
--run add scripts
--run revoke scripts

--ALTER SERVER ROLE [ServerRole-opsmgrsaa] ADD MEMBER [DOD-IG\opsmgrsaa];
--ALTER SERVER ROLE [ServerRole-opsmgrsaa] ADD MEMBER [NT AUTHORITY\SYSTEM];

--REVOKE VIEW ANY DATABASE FROM  [DOD-IG\opsmgrsaa];
--REVOKE VIEW ANY DEFINITION FROM  [DOD-IG\opsmgrsaa];
--REVOKE VIEW SERVER STATE FROM  [DOD-IG\opsmgrsaa];
--REVOKE VIEW SERVER STATE FROM  [NT AUTHORITY\SYSTEM];

