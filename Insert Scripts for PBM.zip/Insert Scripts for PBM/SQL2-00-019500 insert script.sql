use master;
--INSERT INTO master.dbo.GeneralException
--           ([STIGItem]
--           ,[Server]
--           ,[Instance]
--           ,[ExceptionValue]
--           ,[Comments]
--           ,[ModifiedBy]
--           ,[CreateDate])

Select 146, @@SERVERNAME, @@SERVICENAME, db_name(database_id), 'Key_algorithm has been accepted',SUSER_SNAME(), GETDATE()
--SELECT ''?'', *
  FROM sys.dm_database_encryption_keys
 WHERE NOT(encryption_state = 3
 AND ((key_algorithm = 'AES' AND key_length IN (128, 192, 256))
 OR (key_algorithm = 'Triple DES')))
 AND database_id > 4
 AND db_name(database_id) NOT IN (SELECT ExceptionValue FROM master.dbo.GeneralException
	WHERE STIGItem = 146
	AND [Server] = @@SERVERNAME
	AND Instance = @@SERVICENAME)  


