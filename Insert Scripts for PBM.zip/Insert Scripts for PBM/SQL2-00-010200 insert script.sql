--INSERT INTO master.dbo.GeneralException
--           ([STIGItem]
--           ,[Server]
--           ,[Instance]
--           ,[ExceptionValue]
--           ,[Comments]
--           ,[ModifiedBy]
--           ,[CreateDate])

Select 66, @@SERVERNAME, @@SERVICENAME, name, '',SUSER_SNAME(), GETDATE()
--Select *
FROM sys.sql_logins 
WHERE name = SUSER_SNAME(0x01)
AND name = 'sa'
AND name COLLATE Latin1_General_CI_AS_KS_WS NOT IN (SELECT ExceptionValue FROM master.dbo.GeneralException
	WHERE STIGItem = 66
	AND [Server] = @@SERVERNAME
	AND Instance = @@SERVICENAME) 