EXEC sp_MSforeachdb '
--INSERT INTO master.dbo.GeneralException
--           ([STIGItem]
--           ,[Server]
--           ,[Instance]
--           ,[ExceptionValue]
--           ,[Comments]
--           ,[ModifiedBy]
--           ,[CreateDate])
Select 145, @@SERVERNAME, @@SERVICENAME, name, ''?'', SUSER_SNAME(), GETDATE()
--SELECT ''?''
  FROM ?.sys.database_files
 WHERE NOT EXISTS (SELECT 1 FROM ?.sys.database_files
 WHERE type_desc = ''LOG''
   AND state = 0)
 AND ''?'' not in (SELECT master.dbo.GeneralException 
FROM GeneralException
	WHERE STIGItem = 145
	AND [Server] = @@SERVERNAME
	AND Instance = @@SERVICENAME)'   