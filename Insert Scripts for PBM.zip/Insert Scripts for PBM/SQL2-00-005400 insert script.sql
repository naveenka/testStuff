--INSERT INTO master.dbo.GeneralException
--           ([STIGItem]
--           ,[Server]
--           ,[Instance]
--           ,[ExceptionValue]
--           ,[Comments]
--           ,[ModifiedBy]
--           ,[CreateDate])

Select 33, @@SERVERNAME, @@SERVICENAME, name, 'SQL 2008 does not allow custom server roles',SUSER_SNAME(), GETDATE()

--Select *
FROM 
       sys.server_permissions what 
       INNER JOIN sys.server_principals who
              ON who.principal_id = what.grantee_principal_id
WHERE
       what.permission_name = 'Connect SQL'
AND    who.name NOT LIKE '##MS%##'
AND    who.principal_id <> 1 -- Principal 1 is [sa], which may have been renamed
AND    who.type_desc <> 'SERVER_ROLE'
AND name COLLATE Latin1_General_CI_AS_KS_WS NOT IN (SELECT ExceptionValue FROM master.dbo.GeneralException
	WHERE STIGItem = 33
	AND [Server] = @@SERVERNAME
	AND Instance = @@SERVICENAME) 
