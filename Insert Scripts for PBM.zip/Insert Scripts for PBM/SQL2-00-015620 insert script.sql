EXEC sp_MSforeachdb '
USE [?];
 --INSERT INTO master.dbo.GeneralException
 --          ([STIGItem]
 --          ,[Server]
 --          ,[Instance]
 --          ,[ExceptionValue]
 --          ,[Comments]
 --          ,[ModifiedBy]
 --          ,[CreateDate])
Select 138, @@SERVERNAME, @@SERVICENAME, DB_NAME(), '''',SUSER_SNAME(), GETDATE()
--SELECT COUNT(*)
     FROM sys.databases D 
WHERE D.[name] = DB_NAME()
AND    DB_NAME() <> ''msdb''
AND    D.is_trustworthy_on = 1 
AND ISNULL(''?'', '''') NOT IN (SELECT ExceptionValue FROM master.dbo.GeneralException
	WHERE STIGItem = 138
	AND [Server] = @@SERVERNAME
	AND Instance = @@SERVICENAME)  ' 