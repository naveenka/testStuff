
CREATE TABLE #TempSecurables ([State] VARCHAR(500),
            [State2] VARCHAR(200),
            [PermName] VARCHAR(200),
            [Type] NVARCHAR(560),
            [Grantor] VARCHAR(200),
            [User] VARCHAR(200)
            )    

    --Server level Privileges to User or User Group
    INSERT INTO #TempSecurables
    SELECT CASE CAST(p.state AS VARCHAR(100)) WHEN 'D' THEN 'DENY' WHEN 'R' THEN 'REVOKE' WHEN 'G' THEN 'GRANT' WHEN 'W' THEN 'GRANT' END, 
    CASE CAST(p.state AS VARCHAR(100)) WHEN 'W' THEN 'WITH GRANT OPTION' ELSE '' END, CAST(p.permission_name AS VARCHAR(100)), RTRIM(p.class_desc),
    (SELECT [name] FROM sys.server_principals WHERE principal_id = p.grantor_principal_id), CAST(l.name AS VARCHAR(100))
    FROM sys.server_permissions p INNER JOIN sys.server_principals l ON p.grantee_principal_id = l.principal_id
	WHERE l.is_disabled = 0 AND l.type IN ('S', 'U', 'G', 'R')
    ORDER BY CAST(l.name AS VARCHAR(100))

    DECLARE @DBName NVARCHAR(128)
	DECLARE @COUNT INT
	DECLARE @MAXCOUNT INT
	DECLARE @command1 NVARCHAR(MAX)

	SELECT IDENTITY(INT,1,1) AS RowID,
			name
	INTO #TEMP_DB_LIST
	FROM sys.databases WITH (NOLOCK)

	SELECT @COUNT = 1, @MAXCOUNT = COUNT(*)
	FROM #TEMP_DB_LIST

	WHILE (@COUNT <= @MAXCOUNT)
	BEGIN
		SELECT @DBName = name
		FROM #TEMP_DB_LIST
		WHERE RowID = @COUNT
    
		/*
			John DePrato: Added nolocks to system tables
		*/
		SET @command1=REPLACE('	USE [?] 
								--Privileges for Procedures/Functions/CLR/Views to the User
								SELECT CASE WHEN (b.state_desc COLLATE database_default) = ''GRANT_WITH_GRANT_OPTION'' THEN ''GRANT'' ELSE (b.state_desc COLLATE database_default) END + CASE STATE WHEN ''W'' THEN '' WITH GRANT OPTION'' 
								ELSE '''' END , ''[?]'', ''EXECUTE'', ''OBJECT'', c.name + ''.'' + a.name, QUOTENAME(USER_NAME(b.grantee_principal_id)) 
								FROM [?].sys.all_objects a, [?].sys.database_permissions b, [?].sys.schemas c 
								WHERE a.OBJECT_ID = b.major_id AND a.type IN (''X'',''P'',''FN'',''AF'',''FS'',''FT'') AND b.grantee_principal_id <>0 
								AND b.grantee_principal_id <>2 AND a.schema_id = c.schema_id
								ORDER BY c.name

								--Table and View Level Privileges to the User
								SELECT ''GRANT'' , ''[?]'', privilege_type  +
								CASE IS_GRANTABLE WHEN ''YES'' THEN '' WITH GRANT OPTION'' 
								ELSE '''' END , ''OBJECT'',  table_schema + ''.'' + table_name, grantee FROM [?].INFORMATION_SCHEMA.TABLE_PRIVILEGES
								WHERE GRANTEE <> ''public''

								--Column Level Privileges to the User 
								SELECT ''GRANT '', ''[?]'', privilege_type + CASE IS_GRANTABLE WHEN ''YES'' THEN '' WITH GRANT OPTION'' 
								ELSE '''' END , ''OBJECT'', table_schema + ''.'' + table_name + ''('' + column_name + '')'', grantee
								FROM [?].INFORMATION_SCHEMA.COLUMN_PRIVILEGES
								WHERE GRANTEE <> ''public''','?',@DBName)

		INSERT INTO #TempSecurables
		EXEC sp_executesql @command1
    
		SET @COUNT += 1
	END

SELECT DISTINCT 129, @@SERVERNAME, @@SERVICENAME, ISNULL(State2,'') + ' ' + ISNULL(PermName,''), ISNULL(Grantor,'') + '-' + ISNULL(User,''), 'Authorized Securables Access', SUSER_SNAME(), GETDATE()
--SELECT * 
FROM #TempSecurables ts WHERE RTRIM([Type]) <> 'ENDPOINT'
AND NOT EXISTS (SELECT PermissionValue, GranteePersonName
FROM master.dbo.PermissionException WITH (NOLOCK)
	WHERE STIGItem = 129
    AND [Server] = @@SERVERNAME 
	AND Instance = @@SERVICENAME
AND PermissionValue = ISNULL(State2,'') + ' ' + ISNULL(PermName,'')
AND GranteePersonName = ISNULL(Grantor,'') + '-' + ISNULL(User,'') )

DROP TABLE #TempSecurables
 