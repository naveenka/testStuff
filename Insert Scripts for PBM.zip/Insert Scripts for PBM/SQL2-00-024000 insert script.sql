
EXEC sp_MSforeachdb
'USE [?];
--INSERT INTO master.dbo.GeneralException
--           ([STIGItem]
--           ,[Server]
--           ,[Instance]
--           ,[ExceptionValue]
--           ,[Comments]
--           ,[ModifiedBy]
--           ,[CreateDate])

Select 110, @@SERVERNAME, @@SERVICENAME, name, ''?'',SUSER_SNAME(), GETDATE()
--SELECT COUNT(name)
FROM sys.symmetric_keys s, sys.key_encryptions k
WHERE s.name = ''##MS_DatabaseMasterKey##''
AND s.symmetric_key_id = k.key_id
AND k.crypt_type = ''ESKP''
AND ''?'' NOT IN (SELECT Comments FROM master.dbo.GeneralException
	WHERE STIGItem = 110
	AND [Server] = @@SERVERNAME
	AND Instance = @@SERVICENAME)' 
