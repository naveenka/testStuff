--INSERT INTO master.dbo.GeneralException
--           ([STIGItem]
--           ,[Server]
--           ,[Instance]
--           ,[ExceptionValue]
--           ,[Comments]
--           ,[ModifiedBy]
--           ,[CreateDate])

Select 131, @@SERVERNAME, @@SERVICENAME, name, 'Not an Developer account',SUSER_SNAME(), GETDATE()
--SELECT *
FROM sys.server_principals
 WHERE NOT TYPE IN ('C', 'R', 'U') -- ('C', 'G', 'K', 'R', 'S', 'U')
  AND NOT name IN ('##MS_PolicyEventProcessingLogin##', '##MS_PolicyTsqlExecutionLogin##')
  AND sid <> CONVERT(VARBINARY(85), 0x01) -- no 'sa' account
  AND is_disabled <> 1
AND name COLLATE Latin1_General_CI_AS_KS_WS NOT IN (SELECT ExceptionValue FROM master.dbo.GeneralException
	WHERE STIGItem = 131
	AND [Server] = @@SERVERNAME
	AND Instance = @@SERVICENAME)
--AND name IN ('NT SERVICE\SQLAgent$CRM2011', 'DOD-IG\AM-ISD-SI-SQL-Admin')





	 





