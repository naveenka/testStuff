--return all database users and database roles
DECLARE @DB_USers TABLE
(DBName SYSNAME, 
 UserName SYSNAME NULL, 
 LoginType SYSNAME, 
 AssociatedRole VARCHAR(MAX),
 create_date DATETIME,
 modify_date DATETIME)

INSERT @DB_USers
EXEC sp_MSforeachdb
'USE [?]
SELECT ''?'' AS DB_Name, 
CASE CAST(prin.name AS VARCHAR) when ''dbo'' THEN CAST(prin.name AS VARCHAR) + '' (''+ CAST((select SUSER_SNAME(owner_sid) from master.sys.databases where name =''?'') AS VARCHAR) + '')'' else prin.name end AS UserName,
CAST(prin.type_desc AS VARCHAR) AS LoginType, 
ISNULL(USER_NAME(mem.role_principal_id),'''') AS AssociatedRole, 
create_date, modify_date
FROM sys.database_principals prin
LEFT OUTER JOIN sys.database_role_members mem ON prin.principal_id = mem.member_principal_id
WHERE prin.sid IS NOT NULL and prin.sid NOT IN (0x00)
AND mem.role_principal_id IS NOT NULL
AND prin.is_fixed_role <> 1 
AND prin.name NOT LIKE ''##%'' '

--INSERT INTO master.dbo.PermissionException
--           ([STIGItem]
--           ,[Server]
--           ,[Instance]
--           ,[PermissionValue]
--           ,[GranteePersonName]
--           ,[Comments]
--           ,[ModifiedBy]
--		   ,[CreateDate])
SELECT 130 AS 'STIGItem', @@SERVERNAME AS 'Server', @@SERVICENAME AS 'Instance', 
--permissions
--SELECT dbname, username, --logintype, create_date, modify_date,
STUFF(  (SELECT ',' + CONVERT(VARCHAR(500), associatedrole)
FROM @DB_USers user2
WHERE user1.DBName = user2.DBName 
AND user1.UserName = user2.UserName
FOR XML PATH('')  ), 1, 1, '') AS Permission,
ISNULL(dbname, '') + '-' + ISNULL(username, '') AS 'GranteePersonName', '' AS 'Comments',SUSER_SNAME() AS 'ModifiedBy', GETDATE() AS 'CreateDate'
--SELECT COUNT(*)
FROM @DB_USers user1
WHERE dbname + '-' + username COLLATE SQL_Latin1_General_CP1_CI_AS NOT IN (SELECT [GranteePersonName] FROM master.dbo.PermissionException 
	WHERE STIGItem = 130
    AND PermissionValue = (STUFF(  (SELECT ',' + CONVERT(VARCHAR(500), associatedrole)
		FROM @DB_USers user2
		WHERE user1.DBName = user2.DBName 
		AND user1.UserName = user2.UserName
		FOR XML PATH('')  ), 1, 1, '')) 
	AND [Server] = @@SERVERNAME 
	AND Instance = @@SERVICENAME)  
UNION
--return all logins and server roles
 SELECT 130, @@SERVERNAME, @@SERVICENAME, 
 'sysadmin', SL.dbname + '-' + SL.Name COLLATE SQL_Latin1_General_CP1_CI_AS,  '',SUSER_SNAME(), GETDATE()
 FROM sys.syslogins AS SL WHERE SL.sysadmin = 1
 AND SL.dbname + '-' + SL.Name COLLATE Latin1_General_CI_AS_KS_WS NOT IN (SELECT [GranteePersonName] FROM master.dbo.PermissionException 
	WHERE STIGItem = 130
    AND PermissionValue = 'sysadmin' 
	AND [Server] = @@SERVERNAME 
	AND Instance = @@SERVICENAME) 
 UNION
 SELECT 130, @@SERVERNAME, @@SERVICENAME, 
 'securityadmin', SL.dbname + '-' + SL.Name COLLATE SQL_Latin1_General_CP1_CI_AS,  '',SUSER_SNAME(), GETDATE() 
 FROM sys.syslogins AS SL WHERE SL.securityadmin = 1
 AND SL.dbname + '-' + SL.Name COLLATE Latin1_General_CI_AS_KS_WS NOT IN (SELECT [GranteePersonName] FROM master.dbo.PermissionException 
	WHERE STIGItem = 130
    AND PermissionValue = 'securityadmin' 
	AND [Server] = @@SERVERNAME 
	AND Instance = @@SERVICENAME) 
 UNION
 SELECT 130, @@SERVERNAME, @@SERVICENAME, 
 'serveradmin', SL.dbname + '-' + SL.Name COLLATE SQL_Latin1_General_CP1_CI_AS,  '',SUSER_SNAME(), GETDATE() 
 FROM sys.syslogins AS SL WHERE SL.serveradmin = 1
 AND SL.dbname + '-' + SL.Name COLLATE Latin1_General_CI_AS_KS_WS NOT IN (SELECT [GranteePersonName] FROM master.dbo.PermissionException 
	WHERE STIGItem = 130
    AND PermissionValue = 'serveradmin' 
	AND [Server] = @@SERVERNAME 
	AND Instance = @@SERVICENAME) 
 UNION
 SELECT 130, @@SERVERNAME, @@SERVICENAME, 
 'setupadmin', SL.dbname + '-' + SL.Name COLLATE SQL_Latin1_General_CP1_CI_AS,  '',SUSER_SNAME(), GETDATE()
 FROM sys.syslogins AS SL WHERE SL.setupadmin = 1
 AND SL.dbname + '-' + SL.Name COLLATE Latin1_General_CI_AS_KS_WS NOT IN (SELECT [GranteePersonName] FROM master.dbo.PermissionException 
	WHERE STIGItem = 130
    AND PermissionValue = 'setupadmin' 
	AND [Server] = @@SERVERNAME 
	AND Instance = @@SERVICENAME) 
 UNION
 SELECT 130, @@SERVERNAME, @@SERVICENAME, 
 'processadmin', SL.dbname + '-' + SL.Name COLLATE SQL_Latin1_General_CP1_CI_AS,  '',SUSER_SNAME(), GETDATE()
 FROM sys.syslogins AS SL WHERE SL.processadmin = 1
 AND SL.dbname + '-' + SL.Name COLLATE Latin1_General_CI_AS_KS_WS NOT IN (SELECT [GranteePersonName] FROM master.dbo.PermissionException 
	WHERE STIGItem = 130
    AND PermissionValue = 'processadmin' 
	AND [Server] = @@SERVERNAME 
	AND Instance = @@SERVICENAME) 
 UNION
 SELECT 130, @@SERVERNAME, @@SERVICENAME, 
 'diskadmin', SL.dbname + '-' + SL.Name COLLATE SQL_Latin1_General_CP1_CI_AS,  '',SUSER_SNAME(), GETDATE()
 FROM sys.syslogins AS SL WHERE SL.diskadmin = 1
 AND SL.dbname + '-' + SL.Name COLLATE Latin1_General_CI_AS_KS_WS NOT IN (SELECT [GranteePersonName] FROM master.dbo.PermissionException 
	WHERE STIGItem = 130
    AND PermissionValue = 'diskadmin' 
	AND [Server] = @@SERVERNAME 
	AND Instance = @@SERVICENAME) 
 UNION
 SELECT 130, @@SERVERNAME, @@SERVICENAME, 
 'dbcreator', SL.dbname + '-' + SL.Name COLLATE SQL_Latin1_General_CP1_CI_AS,  '',SUSER_SNAME(), GETDATE() 
 FROM sys.syslogins AS SL WHERE SL.dbcreator = 1
 AND SL.dbname + '-' + SL.Name COLLATE Latin1_General_CI_AS_KS_WS NOT IN (SELECT [GranteePersonName] FROM master.dbo.PermissionException 
	WHERE STIGItem = 130
    AND PermissionValue = 'dbcreator' 
	AND [Server] = @@SERVERNAME 
	AND Instance = @@SERVICENAME) 
 UNION
 SELECT 130, @@SERVERNAME, @@SERVICENAME, 
 'bulkadmin', SL.dbname + '-' + SL.Name COLLATE SQL_Latin1_General_CP1_CI_AS,  '',SUSER_SNAME(), GETDATE() 
 FROM sys.syslogins AS SL WHERE SL.bulkadmin = 1
 AND SL.dbname + '-' + SL.Name COLLATE Latin1_General_CI_AS_KS_WS NOT IN (SELECT [GranteePersonName] FROM master.dbo.PermissionException 
	WHERE STIGItem = 130
    AND PermissionValue = 'bulkadmin' 
	AND [Server] = @@SERVERNAME 
	AND Instance = @@SERVICENAME) 


--if null person name is returned set db_owner - then set exception
--use ReportServerCRIMDEV
--exec sp_changedbowner 'ISDDBA'