
--INSERT INTO master.dbo.GeneralException
--           ([STIGItem]
--           ,[Server]
--           ,[Instance]
--           ,[ExceptionValue]
--           ,[Comments]
--           ,[ModifiedBy]
--           ,[CreateDate])
Select 104, @@SERVERNAME, @@SERVICENAME, db_name(), 'Database Master Key is encrypted by the Service Master Key',SUSER_SNAME(), GETDATE()
FROM [master].sys.databases
WHERE is_master_key_encrypted_by_server = 1
AND owner_sid <> 1
AND state = 0
AND db_name() NOT IN (SELECT ExceptionValue FROM master.dbo.GeneralException
	WHERE STIGItem = 104
	AND [Server] = @@SERVERNAME
	AND Instance = @@SERVICENAME) 