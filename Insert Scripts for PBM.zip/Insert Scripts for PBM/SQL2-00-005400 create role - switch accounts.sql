USE [master]
GO

/****** Object:  ServerRole [ServerRole-Connect]    Script Date: 9/28/2015 9:08:07 AM ******/
--CREATE SERVER ROLE [ServerRole-Connect]
--GO
--GRANT CONNECT SQL TO [ServerRole-Connect]
--GO

SELECT 'ALTER SERVER ROLE [ServerRole-Connect] ADD MEMBER [' + name + '];'
FROM 
       sys.server_permissions what 
       INNER JOIN sys.server_principals who
              ON who.principal_id = what.grantee_principal_id
WHERE
       what.permission_name = 'Connect SQL'
AND    who.name NOT LIKE '##MS%##'
AND    who.principal_id <> 1 -- Principal 1 is [sa], which may have been renamed
AND    who.type_desc <> 'SERVER_ROLE'


--Remove users from connect SQL
SELECT 'REVOKE CONNECT SQL FROM  [' + name + '];'
FROM 
       sys.server_permissions what 
       INNER JOIN sys.server_principals who
              ON who.principal_id = what.grantee_principal_id
WHERE
       what.permission_name = 'Connect SQL'
AND    who.name NOT LIKE '##MS%##'
AND    who.principal_id <> 1 -- Principal 1 is [sa], which may have been renamed
AND    who.type_desc <> 'SERVER_ROLE'
GO

USE master;
--run add scripts
--run revoke scripts

