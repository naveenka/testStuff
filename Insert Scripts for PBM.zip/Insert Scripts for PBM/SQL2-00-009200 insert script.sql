--INSERT INTO master.dbo.GeneralException
--           ([STIGItem]
--           ,[Server]
--           ,[Instance]
--           ,[ExceptionValue]
--           ,[Comments]
--			 ,[ModifiedBy]
--			 ,[CreateDate])

Select 118, @@SERVERNAME, @@SERVICENAME, name, 'Not a developer account',SUSER_SNAME(), GETDATE()
--SELECT *
FROM sys.server_principals
 WHERE 
-- 1 <> 1 AND (-- *** for Production comment this out
 TYPE NOT IN ('C', 'R', 'U') -- ('C', 'G', 'K', 'R', 'S', 'U')
  AND NOT name IN ('##MS_PolicyEventProcessingLogin##', '##MS_PolicyTsqlExecutionLogin##')
  AND sid <> CONVERT(VARBINARY(85), 0x01) -- no 'sa' account
  AND is_disabled <> 1
AND name COLLATE Latin1_General_CI_AS_KS_WS NOT IN (SELECT ExceptionValue FROM master.dbo.GeneralException
	WHERE STIGItem = 118
	AND [Server] = @@SERVERNAME
	AND Instance = @@SERVICENAME)
-- ) -- *** for Production comment this out

