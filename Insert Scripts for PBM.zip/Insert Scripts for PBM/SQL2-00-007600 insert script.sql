--INSERT INTO master.dbo.GeneralException
--           ([STIGItem]
--           ,[Server]
--           ,[Instance]
--           ,[ExceptionValue]
--           ,[Comments]
--           ,[ModifiedBy]
--           ,[CreateDate])

Select 55, @@SERVERNAME, @@SERVICENAME, name, '',SUSER_SNAME(), GETDATE()
--Select * 
from sys.server_permissions as per
JOIN sys.server_principals prin 
ON per.grantee_principal_id = prin.principal_id
where permission_name = 'Alter any event notification'
AND name COLLATE Latin1_General_CI_AS_KS_WS NOT IN (SELECT ExceptionValue FROM master.dbo.GeneralException
	WHERE STIGItem = 55
	AND [Server] = @@SERVERNAME
	AND Instance = @@SERVICENAME) 