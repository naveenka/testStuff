EXEC sp_MSforeachdb '
USE [?];
--INSERT INTO master.dbo.GeneralException
--           ([STIGItem]
--           ,[Server]
--           ,[Instance]
--           ,[ExceptionValue]
--           ,[Comments]
--           ,[ModifiedBy]
--           ,[CreateDate])

Select 69, @@SERVERNAME, @@SERVICENAME, ''?'' + '' - '' + permission_name, '''',SUSER_SNAME(), GETDATE()
--SELECT count(*)
--SELECT * 
FROM sys.server_permissions
WHERE state_desc = ''GRANT_WITH_GRANT_OPTION''
AND grantee_principal_id NOT IN (SELECT CAST(ExceptionValue AS INT) 
FROM master.dbo.GeneralException
	WHERE STIGItem = 69
	AND [Server] = @@SERVERNAME
	AND Instance = @@SERVICENAME)
'

--select * from master.dbo.GeneralException
--select * from sys.databases


