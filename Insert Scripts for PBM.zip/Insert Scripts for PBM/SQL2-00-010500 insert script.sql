--INSERT INTO master.dbo.GeneralException
--           ([STIGItem]
--           ,[Server]
--           ,[Instance]
--           ,[ExceptionValue]
--           ,[Comments]
--           ,[ModifiedBy]
--           ,[CreateDate])
Select 141, @@SERVERNAME, @@SERVICENAME, name, 'No Max Audit Files Required',SUSER_SNAME(), GETDATE()
--Select *
FROM sys.server_file_audits
WHERE max_rollover_files = 0
AND name COLLATE Latin1_General_CI_AS_KS_WS NOT IN (SELECT ExceptionValue FROM master.dbo.GeneralException
	WHERE STIGItem = 141
	AND [Server] = @@SERVERNAME
	AND Instance = @@SERVICENAME)
