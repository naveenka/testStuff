--return all database users and database roles
DECLARE @DB_USers TABLE
(DBName sysname, LoginName sysname, UserName sysname NULL, LoginType sysname, --ServerRole varchar(50),
	AssociatedRole varchar(max), create_date datetime, modify_date datetime)

INSERT @DB_USers
EXEC sp_MSforeachdb
'use [?]
SELECT ''?'' AS DB_Name, l.name,
case prin.name when ''dbo'' then prin.name + '' (''+ (select SUSER_SNAME(owner_sid) from master.sys.databases where name =''?'') + '')'' else prin.name end AS UserName,
prin.type_desc AS LoginType, 
--CASE WHEN l.sysadmin = 1 THEN ''sysadmin''
--WHEN l.securityadmin = 1 THEN ''securityadmin''
--WHEN l.serveradmin = 1 THEN ''serveradmin''
--WHEN l.setupadmin = 1 THEN ''setupadmin''
--WHEN l.processadmin = 1 THEN ''processadmin''
--WHEN l.diskadmin = 1 THEN ''diskadmin''
--WHEN l.dbcreator = 1 THEN ''dbcreator''
--WHEN l.bulkadmin = 1 THEN ''bulkadmin'' ELSE ''public'' END, 
isnull(USER_NAME(mem.role_principal_id),'''') AS AssociatedRole , create_date, modify_date
FROM sys.database_principals prin
LEFT OUTER JOIN sys.database_role_members mem ON prin.principal_id=mem.member_principal_id
join master..syslogins l on prin.sid=l.sid 
WHERE prin.sid IS NOT NULL and prin.sid NOT IN (0x00)
and mem.role_principal_id IS NOT NULL
and prin.is_fixed_role <> 1 AND prin.name NOT LIKE ''##%'''

--INSERT INTO master.dbo.PermissionException
--           ([STIGItem]
--           ,[Server]
--           ,[Instance]
--           ,[PermissionValue]
--           ,[GranteePersonName]
--			 ,[Comments]
--           ,[ModifiedBy]
--           ,[CreateDate])
--SELECT COUNT(*)
SELECT DISTINCT 134, @@SERVERNAME, @@SERVICENAME,
--create_date, modify_date,
STUFF( (
SELECT ',' + CONVERT(VARCHAR(500),associatedrole)
FROM @DB_USers user2
WHERE user1.DBName = user2.DBName AND user1.UserName = user2.UserName
FOR XML PATH('') ),1,1,'') AS UserPermission, dbname + '-' + username, 'Authorized Permission',SUSER_SNAME(), GETDATE()
FROM @DB_USers user1
--GROUP BY LoginName, dbname, username, logintype, --ServerRole, 
--create_date, modify_date
--ORDER BY LoginName, dbname, username
WHERE dbname + '-' + username  COLLATE SQL_Latin1_General_CP1_CI_AS
NOT IN (SELECT [GranteePersonName] FROM master.dbo.PermissionException 
	WHERE STIGItem = 134
    AND PermissionValue = (STUFF( (
SELECT ',' + CONVERT(VARCHAR(500),associatedrole)
FROM @DB_USers user2
WHERE user1.DBName = user2.DBName AND user1.UserName = user2.UserName
FOR XML PATH('') ),1,1,'')) 
	AND [Server] = @@SERVERNAME 
	AND Instance = @@SERVICENAME) 
AND UserName IS NOT NULL
--AND username NOT IN ('DOD-IG\MitchellV', 'DOD-IG\charlesl', 'DOD-IG\vietn')


--return all logins and server roles
--INSERT INTO master.dbo.PermissionException
--           ([STIGItem]
--           ,[Server]
--           ,[Instance]
--           ,[PermissionValue]
--           ,[GranteePersonName]
--			 ,[Comments]
--           ,[ModifiedBy]
--           ,[CreateDate])
--SELECT COUNT(*)
 SELECT DISTINCT 134, @@Servername, @@SERVICENAME, 'sysadmin' AS 'ServerRole', SL.Name, 'Account accept to have sysadmin rights',SUSER_SNAME(), GETDATE()
 FROM sys.syslogins AS SL WHERE SL.sysadmin = 1
 AND sid != 0x01
 AND SL.Name COLLATE Latin1_General_CI_AS_KS_WS NOT IN (SELECT [GranteePersonName] FROM master.dbo.PermissionException 
	WHERE STIGItem = 134
    AND PermissionValue = 'sysadmin' 
	AND [Server] = @@SERVERNAME 
	AND Instance = @@SERVICENAME) 
 UNION
 SELECT DISTINCT 134, @@Servername, @@SERVICENAME, 'securityadmin' AS 'ServerRole', SL.Name, 'Account accept to have securityadmin rights',SUSER_SNAME(), GETDATE()
 FROM sys.syslogins AS SL WHERE SL.securityadmin = 1
 AND SL.Name COLLATE Latin1_General_CI_AS_KS_WS NOT IN (SELECT [GranteePersonName] FROM master.dbo.PermissionException 
	WHERE STIGItem = 134
    AND PermissionValue = 'securityadmin' 
	AND [Server] = @@SERVERNAME 
	AND Instance = @@SERVICENAME)
 UNION
 SELECT DISTINCT 134, @@Servername, @@SERVICENAME, 'serveradmin' AS 'ServerRole', SL.Name, 'Account accept to have serveradmin rights',SUSER_SNAME(), GETDATE()
 FROM sys.syslogins AS SL WHERE SL.serveradmin = 1
 AND SL.Name COLLATE Latin1_General_CI_AS_KS_WS NOT IN (SELECT [GranteePersonName] FROM master.dbo.PermissionException 
	WHERE STIGItem = 134
    AND PermissionValue = 'serveradmin' 
	AND [Server] = @@SERVERNAME 
	AND Instance = @@SERVICENAME)
 UNION
 SELECT DISTINCT 134, @@Servername, @@SERVICENAME, 'setupadmin' AS 'ServerRole', SL.Name, 'Account accept to have setupadmin rights',SUSER_SNAME(), GETDATE()
 FROM sys.syslogins AS SL WHERE SL.setupadmin = 1
 AND SL.Name COLLATE Latin1_General_CI_AS_KS_WS NOT IN (SELECT [GranteePersonName] FROM master.dbo.PermissionException 
	WHERE STIGItem = 134
    AND PermissionValue = 'setupadmin' 
	AND [Server] = @@SERVERNAME 
	AND Instance = @@SERVICENAME)
 UNION
 SELECT DISTINCT 134, @@Servername, @@SERVICENAME, 'processadmin' AS 'ServerRole', SL.Name, 'Account accept to have processadmin rights',SUSER_SNAME(), GETDATE()
 FROM sys.syslogins AS SL WHERE SL.processadmin = 1
 AND SL.Name COLLATE Latin1_General_CI_AS_KS_WS NOT IN (SELECT [GranteePersonName] FROM master.dbo.PermissionException 
	WHERE STIGItem = 134
    AND PermissionValue = 'processadmin' 
	AND [Server] = @@SERVERNAME 
	AND Instance = @@SERVICENAME)
 UNION
 SELECT DISTINCT 134, @@Servername, @@SERVICENAME, 'diskadmin' AS 'ServerRole', SL.Name, 'Account accept to have diskadmin rights',SUSER_SNAME(), GETDATE()
 FROM sys.syslogins AS SL WHERE SL.diskadmin = 1
 AND SL.Name COLLATE Latin1_General_CI_AS_KS_WS NOT IN (SELECT [GranteePersonName] FROM master.dbo.PermissionException 
	WHERE STIGItem = 134
    AND PermissionValue = 'diskadmin' 
	AND [Server] = @@SERVERNAME 
	AND Instance = @@SERVICENAME)
 UNION
 SELECT DISTINCT 134, @@Servername, @@SERVICENAME, 'dbcreator' AS 'ServerRole', SL.Name, 'Account accept to have dbcreator rights',SUSER_SNAME(), GETDATE()
 FROM sys.syslogins AS SL WHERE SL.dbcreator = 1
 AND SL.Name COLLATE Latin1_General_CI_AS_KS_WS NOT IN (SELECT [GranteePersonName] FROM master.dbo.PermissionException 
	WHERE STIGItem = 134
    AND PermissionValue = 'dbcreator' 
	AND [Server] = @@SERVERNAME 
	AND Instance = @@SERVICENAME)
 UNION
 SELECT DISTINCT 134, @@Servername, @@SERVICENAME, 'bulkadmin' AS 'ServerRole', SL.Name, 'Account accept to have bulkadmin rights',SUSER_SNAME(), GETDATE()
 FROM sys.syslogins AS SL WHERE SL.bulkadmin = 1
 AND SL.Name COLLATE Latin1_General_CI_AS_KS_WS NOT IN (SELECT [GranteePersonName] FROM master.dbo.PermissionException 
	WHERE STIGItem = 134
    AND PermissionValue = 'bulkadmin' 
	AND [Server] = @@SERVERNAME 
	AND Instance = @@SERVICENAME)

 --list direct server permissions to the login accounts
DECLARE    @PartnerServer sysname,
    @Debug bit = 0

SET @PartnerServer = @@SERVERNAME

Declare @MaxID int,
    @CurrID int,
    @SQL nvarchar(max),
    @LoginName sysname,
    @IsDisabled int,
    @Type char(1),
    @SID varbinary(85),
    @SIDString nvarchar(100),
    @PasswordHash varbinary(256),
    @PasswordHashString nvarchar(300),
    @RoleName sysname,
    @Machine sysname,
    @PermState nvarchar(60),
    @PermName sysname,
    @Class tinyint,
    @MajorID int,
    @ErrNumber int,
    @ErrSeverity int,
    @ErrState int,
    @ErrProcedure sysname,
    @ErrLine int,
    @ErrMsg nvarchar(2048)

Declare @Logins Table (LoginID int identity(1, 1) not null primary key,
                        [Name] sysname not null,
                        [SID] varbinary(85) not null,
                        IsDisabled int not null,
                        [Type] char(1) not null,
                        PasswordHash varbinary(256) null)
Declare @Roles Table (RoleID int identity(1, 1) not null primary key,
                    RoleName sysname not null,
                    LoginName sysname not null)
Declare @Perms Table (PermID int identity(1, 1) not null primary key,
                    LoginName sysname not null,
                    PermState nvarchar(60) not null,
                    PermName sysname not null,
                    Class tinyint not null,
                    ClassDesc nvarchar(60) not null,
                    MajorID int not null,
                    SubLoginName sysname null,
                    SubEndPointName sysname null)

Set NoCount On;

If CharIndex('\', @PartnerServer) > 0
  Begin
    Set @Machine = LEFT(@PartnerServer, CharIndex('\', @PartnerServer) - 1);
  End
Else
  Begin
    Set @Machine = @PartnerServer;
  End

-- Get all Windows logins from principal server
Set @SQL = 'Select P.name, P.sid, P.is_disabled, P.type, L.password_hash' + CHAR(10) +
        'From ' + QUOTENAME(@PartnerServer) + '.master.sys.server_principals P' + CHAR(10) +
        'Left Join ' + QUOTENAME(@PartnerServer) + '.master.sys.sql_logins L On L.principal_id = P.principal_id' + CHAR(10) +
        'Where P.type In (''U'', ''G'', ''S'')' + CHAR(10) +
        'And P.sid <> 0x01' + CHAR(10) +
        'And P.name Not Like ''##%''' + CHAR(10) 
		;
		--+ 'And CharIndex(''' + @Machine + '\'', P.name) = 0;';
 
Insert Into @Logins (Name, SID, IsDisabled, Type, PasswordHash)
Exec sp_executesql @SQL;

-- Get all roles from principal server
Set @SQL = 'Select RoleP.name, LoginP.name' + CHAR(10) +
        'From ' + QUOTENAME(@PartnerServer) + '.master.sys.server_role_members RM' + CHAR(10) +
        'Inner Join ' + QUOTENAME(@PartnerServer) + '.master.sys.server_principals RoleP' +
        CHAR(10) + char(9) + 'On RoleP.principal_id = RM.role_principal_id' + CHAR(10) +
        'Inner Join ' + QUOTENAME(@PartnerServer) + '.master.sys.server_principals LoginP' +
        CHAR(10) + char(9) + 'On LoginP.principal_id = RM.member_principal_id' + CHAR(10) +
        'Where LoginP.type In (''U'', ''G'', ''S'')' + CHAR(10) +
        'And LoginP.sid <> 0x01' + CHAR(10) +
        'And LoginP.name Not Like ''##%''' + CHAR(10) +
        'And RoleP.type = ''R''' + CHAR(10) 
		--+ 'And CharIndex(''' + @Machine + '\'', LoginP.name) = 0;';

Insert Into @Roles (RoleName, LoginName)
Exec sp_executesql @SQL;

-- Get all explicitly granted permissions
Set @SQL = 'Select P.name Collate database_default,' + CHAR(10) +
        '   SP.state_desc, SP.permission_name, SP.class, SP.class_desc, SP.major_id,' + CHAR(10) +
        '   SubP.name Collate database_default,' + CHAR(10) +
        '   SubEP.name Collate database_default' + CHAR(10) +
        'From ' + QUOTENAME(@PartnerServer) + '.master.sys.server_principals P' + CHAR(10) +
        'Inner Join ' + QUOTENAME(@PartnerServer) + '.master.sys.server_permissions SP' + CHAR(10) +
        CHAR(9) + 'On SP.grantee_principal_id = P.principal_id' + CHAR(10) +
        'Left Join ' + QUOTENAME(@PartnerServer) + '.master.sys.server_principals SubP' + CHAR(10) +
        CHAR(9) + 'On SubP.principal_id = SP.major_id And SP.class = 101' + CHAR(10) +
        'Left Join ' + QUOTENAME(@PartnerServer) + '.master.sys.endpoints SubEP' + CHAR(10) +
        CHAR(9) + 'On SubEP.endpoint_id = SP.major_id And SP.class = 105' + CHAR(10) +
        'Where P.type In (''U'', ''G'', ''S'')' + CHAR(10) +
        'AND p.sid <> 0x01' + CHAR(10) +
        'And P.name Not Like ''##%''' + CHAR(10) 
		--+ 'And CharIndex(''' + @Machine + '\'', P.name) = 0;'

Insert Into @Perms (LoginName, PermState, PermName, Class, ClassDesc, MajorID, SubLoginName, SubEndPointName)
Exec sp_executesql @SQL;

--return all logins and server roles
--INSERT INTO master.dbo.PermissionException
--           ([STIGItem]
--           ,[Server]
--           ,[Instance]
--           ,[PermissionValue]
--           ,[GranteePersonName]
--			 ,[Comments]
--           ,[ModifiedBy]
--           ,[CreateDate])
--SELECT COUNT(*)
 SELECT DISTINCT 134, @@Servername, @@SERVICENAME, PermName, LoginName , '',SUSER_SNAME(), GETDATE()
from @Perms
WHERE LoginName COLLATE SQL_Latin1_General_CP1_CI_AS NOT IN (SELECT [GranteePersonName] FROM master.dbo.PermissionException 
	WHERE STIGItem = 134
    AND PermissionValue COLLATE SQL_Latin1_General_CP1_CI_AS = PermName COLLATE SQL_Latin1_General_CP1_CI_AS 
	AND [Server] = @@SERVERNAME 
	AND Instance = @@SERVICENAME) and PermName <> 'CONNECT SQL'


--If there is a null value in the user_permission column it means there is no DB owner assigned
--run the following to correct
/*
use <database name>
go
exec sp_changedbowner 'ISDDBA'
go
*/




 


