--INSERT INTO master.dbo.GeneralException
--           ([STIGItem]
--           ,[Server]
--           ,[Instance]
--           ,[ExceptionValue]
--           ,[Comments]
--           ,[ModifiedBy]
--           ,[CreateDate])
Select 89, @@SERVERNAME, @@SERVICENAME, name, 'xp_cmdshell Used', SUSER_SNAME(), GETDATE()
--SELECT *
FROM sys.configurations
WHERE name = 'xp_cmdshell'
AND value_in_use = 1
AND name COLLATE Latin1_General_CI_AS_KS_WS not in (SELECT ExceptionValue 
FROM master.dbo.GeneralException
	WHERE STIGItem = 89
	AND [Server] = @@SERVERNAME
	AND Instance = @@SERVICENAME)