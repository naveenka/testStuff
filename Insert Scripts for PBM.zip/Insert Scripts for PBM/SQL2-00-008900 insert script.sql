SET NOCOUNT ON

DECLARE @SQLService  	NVARCHAR(60)
DECLARE @AgentService  	NVARCHAR(60)
DECLARE @FTService  	NVARCHAR(60)
DECLARE @SSASService  	NVARCHAR(60)
DECLARE @SSRSService  	NVARCHAR(60)
DECLARE @SSISService  	NVARCHAR(60)
DECLARE @DCOMService  	NVARCHAR(60)
DECLARE @VSSService  	NVARCHAR(60)
DECLARE @Instance	  	NVARCHAR(60)
DECLARE @WorkingNm		NVARCHAR(60)
DECLARE @RKey			NVARCHAR(60)
DECLARE @RtrnCd			TINYINT

SET @RtrnCd = 0

SET @Instance = @@SERVICENAME

-- we get the instance aware service accounts below
IF @Instance = 'MSSQLSERVER' 
BEGIN
BEGIN TRY

-- get default instance service account
EXEC xp_instance_regread @root_key  	= 'HKEY_LOCAL_MACHINE',
   				@key  		= 'SYSTEM\ControlSet001\Services\MSSQLServer',
		   		@valuename 	= 'ObjectName',
				@value   	= @SQLService output
IF CHARINDEX('/', @SQLService) = 0
	IF CHARINDEX('@', @SQLService) != 0
	BEGIN
	--PRINT @@SQLService
	SET @SQLService = (SUBSTRING(@SQLService, (CHARINDEX('@', @SQLService) + 1), (LEN(@SQLService)))) + '\' + 
		SUBSTRING(@SQLService, 1, (CHARINDEX('@', @SQLService)))
	SET @SQLService = (SUBSTRING(@SQLService, 1, LEN(@SQLService) - 1))
	--PRINT @SQLService
	END
END TRY
BEGIN CATCH
	SET @SQLService = NULL
END CATCH
--SELECT @SQLService as 'SQLService'

-- get default instance agent account
BEGIN TRY
EXEC xp_instance_regread @root_key  	= 'HKEY_LOCAL_MACHINE',
				@key   		= 'SYSTEM\ControlSet001\Services\SQLSERVERAGENT',
				@valuename  	= 'ObjectName',
				@value   	= @AgentService output
IF CHARINDEX('/', @AgentService) = 0
	IF CHARINDEX('@', @AgentService) != 0
	BEGIN
	--PRINT @AgentService
	SET @AgentService = (SUBSTRING(@AgentService, (CHARINDEX('@', @AgentService) + 1), (LEN(@AgentService)))) + '\' + 
		SUBSTRING(@AgentService, 1, (CHARINDEX('@', @AgentService)))
	SET @AgentService = (SUBSTRING(@AgentService, 1, LEN(@AgentService) - 1))
	--PRINT @AgentService
	END
END TRY
BEGIN CATCH
	SET @AgentService = NULL
END CATCH
--SELECT @AgentService as 'AgentService' 

-- get default instance full text account
BEGIN TRY

EXEC xp_instance_regread @root_key  	= 'HKEY_LOCAL_MACHINE',
--				@key   		= 'SYSTEM\ControlSet001\Services\MSSQLFDLauncher',
				@key   		= 'SYSTEM\ControlSet001\Services\MSFTESQL',
				@valuename  	= 'ObjectName',
				@value   	= @FTService output

IF CHARINDEX('/', @FTService) = 0
	IF CHARINDEX('@', @FTService) != 0
	BEGIN
	--PRINT @FTService
	SET @FTService = (SUBSTRING(@FTService, (CHARINDEX('@', @FTService) + 1), (LEN(@FTService)))) + '\' + 
		SUBSTRING(@FTService, 1, (CHARINDEX('@', @FTService)))
	SET @FTService = (SUBSTRING(@FTService, 1, LEN(@FTService) - 1))
	--PRINT @FTService
	END
END TRY
BEGIN CATCH
	SET @FTService = NULL
END CATCH
--SELECT @FTService as 'FTService' 
END
ELSE
BEGIN
BEGIN TRY
--print @Instance
SET @WorkingNm = 'MSSQL$' + @Instance
SET @RKey = 'SYSTEM\ControlSet001\Services\' + @WorkingNm + '\'

-- get named instance sql account
EXEC xp_instance_regread @root_key  	= 'HKEY_LOCAL_MACHINE',
   				@key  		= @RKey,
		   		@valuename 	= 'ObjectName',
				@value   	= @SQLService output
IF CHARINDEX('/', @SQLService) = 0
	IF CHARINDEX('@', @SQLService) != 0
	BEGIN
	--PRINT @@SQLService
	SET @SQLService = (SUBSTRING(@SQLService, (CHARINDEX('@', @SQLService) + 1), (LEN(@SQLService)))) + '\' + 
		SUBSTRING(@SQLService, 1, (CHARINDEX('@', @SQLService)))
	SET @SQLService = (SUBSTRING(@SQLService, 1, LEN(@SQLService) - 1))
	--PRINT @SQLService
	END
END TRY
BEGIN CATCH
	SET @SQLService = NULL
END CATCH
--SELECT @SQLService as 'SQLService' 
 
SET @WorkingNm = 'SQLAgent$' + @Instance	
SET @RKey = 'SYSTEM\ControlSet001\Services\' + @WorkingNm + '\'	
	
-- get named instance agent account	
BEGIN TRY						
EXEC xp_instance_regread @root_key  	= 'HKEY_LOCAL_MACHINE',
				@key   		= @RKey,
				@valuename  	= 'ObjectName',
				@value   	= @AgentService output
IF CHARINDEX('/', @AgentService) = 0
	IF CHARINDEX('@', @AgentService) != 0
	BEGIN
	--PRINT @AgentService
	SET @AgentService = (SUBSTRING(@AgentService, (CHARINDEX('@', @AgentService) + 1), (LEN(@AgentService)))) + '\' + 
		SUBSTRING(@AgentService, 1, (CHARINDEX('@', @AgentService)))
	SET @AgentService = (SUBSTRING(@AgentService, 1, LEN(@AgentService) - 1))
	--PRINT @AgentService
	END
END TRY
BEGIN CATCH
	SET @AgentService = NULL
END CATCH
--SELECT @AgentService as 'AgentService'

SET @WorkingNm = 'MSSQLFDLauncher$' + @Instance	
SET @RKey = 'SYSTEM\ControlSet001\Services\' + @WorkingNm + '\'		

-- get default instance full text account
BEGIN TRY
EXEC xp_instance_regread @root_key  	= N'HKEY_LOCAL_MACHINE',
				@key   					= @RKey,
				@valuename  			= 'ObjectName',
				@Value					= @FTService output
IF CHARINDEX('/', @FTService) = 0
	IF CHARINDEX('@', @FTService) != 0
	BEGIN
	--PRINT @FTService
	SET @FTService = (SUBSTRING(@FTService, (CHARINDEX('@', @FTService) + 1), (LEN(@FTService)))) + '\' + 
		SUBSTRING(@FTService, 1, (CHARINDEX('@', @FTService)))
	SET @FTService = (SUBSTRING(@FTService, 1, LEN(@FTService) - 1))
	--PRINT @FTService
	END
END TRY
BEGIN CATCH
	SET @FTService = NULL
END CATCH

SET @WorkingNm = 'MSOLAP$' + @Instance	
SET @RKey = 'SYSTEM\ControlSet001\Services\' + @WorkingNm + '\'	
END

---- get SSAS account
BEGIN TRY
EXEC xp_instance_regread @root_key  	= 'HKEY_LOCAL_MACHINE',
				@key   					= @RKey,
				@valuename  			= 'ObjectName',
				@value   				= @SSASService output
END TRY
BEGIN CATCH
	SET @SSASService = NULL
END CATCH
--SELECT @SSASService as 'SSASService'

SET @WorkingNm = 'ReportServer$' + @Instance	
SET @RKey = 'SYSTEM\ControlSet001\Services\' + @WorkingNm + '\'	

-- get SSRS account
BEGIN TRY
EXEC xp_instance_regread @root_key  	= 'HKEY_LOCAL_MACHINE',
				@key   		= @RKey,
				@valuename  	= 'ObjectName',
				@value   	= @SSRSService output
END TRY
BEGIN CATCH
	SET @SSRSService = NULL
END CATCH
--SELECT @SSRSService as 'SSRSService'


-- now for the instance unaware services
-- get ssis service account
BEGIN TRY
EXEC xp_instance_regread @root_key  	= 'HKEY_LOCAL_MACHINE',
				@key   		= 'SYSTEM\ControlSet001\Services\MsDtsServer110',
				@valuename  	= 'ObjectName',
				@value   	= @SSISService output
END TRY
BEGIN CATCH
	SET @SSISService = NULL
END CATCH
--SELECT @SSISService as 'SSISService'

-- get vss service account
BEGIN TRY
EXEC xp_instance_regread @root_key  	= 'HKEY_LOCAL_MACHINE',
				@key   		= 'SYSTEM\ControlSet001\Services\SQLWriter',
				@valuename  	= 'ObjectName',
				@value   	= @VSSService output
END TRY
BEGIN CATCH
	SET @VSSService = NULL
END CATCH
--SELECT @VSSService as 'VSSService'

-- get SQL Distributed Replay Ckient service account
BEGIN TRY
EXEC xp_instance_regread @root_key  	= 'HKEY_LOCAL_MACHINE',
				@key   		= 'SYSTEM\ControlSet001\Services\SQL Server Distributed Replay Client',
				@valuename  	= 'ObjectName',
				@value   	= @DCOMService output
END TRY
BEGIN CATCH
	SET @DCOMService = NULL
END CATCH;
--SELECT @DCOMService as '@DCOMService'
			
--print the output for testing
--SELECT  	@SQLService      AS 'SQL Service Account',
--  			@AgentService    AS 'SQL Agent Account',
--			@FTService  	 AS 'Full Text Search',
--			@SSASService  	 AS 'SSAS Account', 
--			@SSRSService  	 AS 'SSRS Account',
--			@SSISService  	 AS 'SSIS Account',
--			@DCOMService  	 AS 'DCOM Client Account',
--			@VSSService      AS 'SQL VSS Account'
			
-- Evaluate the accounts
IF ((@SQLService IS NULL)
	OR ('SQLService' IN (SELECT ExceptionValue FROM master.dbo.GeneralException
	WHERE STIGItem = 65 AND [Server] = @@SERVERNAME AND Instance = @@SERVICENAME)))
	OR ((@SQLService NOT IN (SELECT ServiceAcctName FROM master.dbo.SQLServiceAccounts
	WHERE (ServerName <> @@SERVERNAME) OR (InstanceName <> @@SERVICENAME)) ) )  
	BEGIN
	SET @RtrnCd = 0;
	END
	ELSE
	BEGIN
	SET @RtrnCd = 1;
	END
--SELECT @RtrnCd AS RtrnCd1a;
IF ((@AgentService IS NULL)
	OR ('AgentService' IN (SELECT ExceptionValue FROM master.dbo.GeneralException
	WHERE STIGItem = 65 AND [Server] = @@SERVERNAME AND Instance = @@SERVICENAME)))
	OR ((@FTService NOT IN (SELECT ServiceAcctName FROM master.dbo.SQLServiceAccounts
	WHERE (ServerName <> @@SERVERNAME) OR (InstanceName <> @@SERVICENAME)) )  )
	BEGIN
	SET @RtrnCd = 0;
	END
	ELSE
	BEGIN
	SET @RtrnCd = 1;
	END
--SELECT @RtrnCd AS RtrnCd1b;
If ((@SSASService IS NULL)
	OR ('SSASService' IN (SELECT ExceptionValue FROM master.dbo.GeneralException
	WHERE STIGItem = 65 AND [Server] = @@SERVERNAME AND Instance = @@SERVICENAME)))
	OR ((@SSASService NOT IN (SELECT ServiceAcctName FROM master.dbo.SQLServiceAccounts
	WHERE (ServerName <> @@SERVERNAME) OR (InstanceName <> @@SERVICENAME)) )  )
	BEGIN
	SET @RtrnCd = 0;
	END
	ELSE
	BEGIN
		IF (@SSASService IS NULL)
		SET @RtrnCd = 0
		ELSE
		SET @RtrnCd = 1;
	END
--SELECT @RtrnCd AS RtrnCd1c;
IF ((@SSISService IS NULL)
	OR ('SSISService' IN (SELECT ExceptionValue FROM master.dbo.GeneralException
	WHERE STIGItem = 65 AND [Server] = @@SERVERNAME AND Instance = @@SERVICENAME)))
	OR ((@SSISService NOT IN (SELECT ServiceAcctName FROM master.dbo.SQLServiceAccounts
	WHERE (ServerName <> @@SERVERNAME) OR (InstanceName <> @@SERVICENAME)) )  )
	BEGIN
	SET @RtrnCd = 0;
	END
	ELSE
	BEGIN
		IF (@SSISService IS NULL)
		SET @RtrnCd = 0
		ELSE
		SET @RtrnCd = 1;
	END
--SELECT @RtrnCd AS RtrnCd1d;
--IF (@VSSService IS NULL)
--	OR ('VSSService' IN (SELECT ExceptionValue FROM master.dbo.GeneralException
--	WHERE STIGItem = 65 AND [Server] = @@SERVERNAME AND Instance = @@SERVICENAME))
--	OR ((@VSSService NOT IN (SELECT ServiceAcctName FROM master.dbo.SQLServiceAccounts
--	WHERE (ServerName <> @@SERVERNAME) OR (InstanceName <> @@SERVICENAME)) )  ) 
--	BEGIN
--	SET @RtrnCd = 0;
--	END
--	ELSE
--	BEGIN
--		IF (@VSSService IS NULL)
--		SET @RtrnCd = 0
--		ELSE
--		SET @RtrnCd = 1;
--	END

--SELECT @RtrnCd AS RtrnCd1e;

SELECT ServerName, InstanceName, ServiceAcctType, ServiceAcctDomain, ServiceAcctName, DateAdded
INTO ##temptable
FROM master.dbo.SQLServiceAccounts
WHERE [ServerName] = @@SERVERNAME AND InstanceName = @@SERVICENAME

---- evaluate / save the sql server service account
IF (@RtrnCd = 0) AND (@SQLService IS NOT NULL) AND (LOWER(@SQLService) NOT IN ('localsystem', 'localservice'))
MERGE ##temptable AS target
    USING (SELECT @@SERVERNAME, @@SERVICENAME) AS source (ServerNameIN, ServiceNameIN)
    ON ((target.ServerName = source.ServerNameIN) AND (target.InstanceName = source.ServiceNameIN)
		AND (ServiceAcctType = 1))
    WHEN MATCHED THEN 
        UPDATE SET ServiceAcctDomain = (SUBSTRING(@SQLService, 1, CHARINDEX('\', @SQLService) - 1)),
			ServiceAcctName = (SUBSTRING(@SQLService, (CHARINDEX('\', @SQLService) + 1), (LEN(@SQLService))))
        WHEN NOT MATCHED THEN  
            INSERT (ServerName, InstanceName, ServiceAcctType, ServiceAcctDomain, ServiceAcctName)
            VALUES (@@SERVERNAME, @@SERVICENAME, 1, 
				(SUBSTRING(@SQLService, 1, CHARINDEX('\', @SQLService) - 1)), 
				(SUBSTRING(@SQLService, (CHARINDEX('\', @SQLService) + 1), (LEN(@SQLService)))));

-- evaluate / save the sql agent service account
IF (@RtrnCd = 0) AND (@AgentService IS NOT NULL) AND (LOWER(@AgentService) NOT IN ('localsystem', 'localservice'))
MERGE ##temptable AS target
    USING (SELECT @@SERVERNAME, @@SERVICENAME) AS source (ServerNameIN, ServiceNameIN)
    ON ((target.ServerName = source.ServerNameIN) AND (target.InstanceName = source.ServiceNameIN)
		AND (ServiceAcctType = 2))
    WHEN MATCHED THEN 
        UPDATE SET ServiceAcctDomain = (SUBSTRING(@AgentService, 1, CHARINDEX('\', @AgentService) - 1)),
			ServiceAcctName = (SUBSTRING(@AgentService, (CHARINDEX('\', @AgentService) + 1), (LEN(@AgentService))))
        WHEN NOT MATCHED THEN  
            INSERT (ServerName, InstanceName, ServiceAcctType, ServiceAcctDomain, ServiceAcctName)
            VALUES (@@SERVERNAME, @@SERVICENAME, 2, 
				(SUBSTRING(@AgentService, 1, CHARINDEX('\', @AgentService) - 1)), 
				(SUBSTRING(@AgentService, (CHARINDEX('\', @AgentService) + 1), (LEN(@AgentService)))));

-- evaluate / save the sql server full text search account
IF (@RtrnCd = 0) AND (@FTService IS NOT NULL) AND (LOWER(@FTService) NOT IN ('localsystem', 'localservice', 'nt authority\localservice'))
MERGE ##temptable AS target
    USING (SELECT @@SERVERNAME, @@SERVICENAME) AS source (ServerNameIN, ServiceNameIN)
    ON ((target.ServerName = source.ServerNameIN) AND (target.InstanceName = source.ServiceNameIN)
		AND (ServiceAcctType = 3))
    WHEN MATCHED THEN 
        UPDATE SET ServiceAcctDomain = (SUBSTRING(@FTService, 1, CHARINDEX('\', @FTService) - 1)),
			ServiceAcctName = (SUBSTRING(@FTService, (CHARINDEX('\', @FTService) + 1), (LEN(@FTService))))
        WHEN NOT MATCHED THEN  
            INSERT (ServerName, InstanceName, ServiceAcctType, ServiceAcctDomain, ServiceAcctName)
            VALUES (@@SERVERNAME, @@SERVICENAME, 3, 
				(SUBSTRING(@FTService, 1, CHARINDEX('\', @FTService) - 1)), 
				(SUBSTRING(@FTService, (CHARINDEX('\', @FTService) + 1), (LEN(@FTService)))));

-- evaluate / save the sql analysis server service account
IF (@RtrnCd = 0) AND (@SSASService IS NOT NULL) AND (LOWER(@SSASService) NOT IN ('localsystem', 'localservice'))
MERGE ##temptable AS target
    USING (SELECT @@SERVERNAME, @@SERVICENAME) AS source (ServerNameIN, ServiceNameIN)
    ON ((target.ServerName = source.ServerNameIN) AND (target.InstanceName = source.ServiceNameIN)
		AND (ServiceAcctType = 4))
    WHEN MATCHED THEN 
        UPDATE SET ServiceAcctDomain = (SUBSTRING(@SSASService, 1, CHARINDEX('\', @SSASService) - 1)),
			ServiceAcctName = (SUBSTRING(@SSASService, (CHARINDEX('\', @SSASService) + 1), (LEN(@SSASService))))
        WHEN NOT MATCHED THEN  
            INSERT (ServerName, InstanceName, ServiceAcctType, ServiceAcctDomain, ServiceAcctName)
            VALUES (@@SERVERNAME, @@SERVICENAME, 4, 
				(SUBSTRING(@SSASService, 1, CHARINDEX('\', @SSASService) - 1)), 
				(SUBSTRING(@SSASService, (CHARINDEX('\', @SSASService) + 1), (LEN(@SSASService)))));

-- evaluate / save the sql reporting service account
IF (@RtrnCd = 0) AND (@SSRSService IS NOT NULL) AND (LOWER(@SSRSService) NOT IN ('localsystem', 'localservice')) 
MERGE ##temptable AS target
    USING (SELECT @@SERVERNAME, @@SERVICENAME) AS source (ServerNameIN, ServiceNameIN)
    ON ((target.ServerName = source.ServerNameIN) AND (target.InstanceName = source.ServiceNameIN)
		AND (ServiceAcctType = 5))
    WHEN MATCHED THEN 
        UPDATE SET ServiceAcctDomain = (SUBSTRING(@SSRSService, 1, CHARINDEX('\', @SSRSService) - 1)),
			ServiceAcctName = (SUBSTRING(@SSRSService, (CHARINDEX('\', @SSRSService) + 1), (LEN(@SSRSService))))
        WHEN NOT MATCHED THEN  
            INSERT (ServerName, InstanceName, ServiceAcctType, ServiceAcctDomain, ServiceAcctName)
            VALUES (@@SERVERNAME, @@SERVICENAME, 5, 
				(SUBSTRING(@SSRSService, 1, CHARINDEX('\', @SSRSService) - 1)), 
				(SUBSTRING(@SSRSService, (CHARINDEX('\', @SSRSService) + 1), (LEN(@SSRSService)))));

-- evaluate / save the sql integration service account
IF (@RtrnCd = 0) AND (@SSISService IS NOT NULL) AND (LOWER(@SSISService) NOT IN ('localsystem', 'localservice'))  
MERGE ##temptable AS target
    USING (SELECT @@SERVERNAME, @@SERVICENAME) AS source (ServerNameIN, ServiceNameIN)
    ON ((target.ServerName = source.ServerNameIN) AND (target.InstanceName = source.ServiceNameIN)
		AND (ServiceAcctType = 6))
    WHEN MATCHED THEN 
        UPDATE SET ServiceAcctDomain = (SUBSTRING(@SSISService, 1, CHARINDEX('\', @SSISService) - 1)),
			ServiceAcctName = (SUBSTRING(@SSISService, (CHARINDEX('\', @SSISService) + 1), (LEN(@SSISService))))
        WHEN NOT MATCHED THEN  
            INSERT (ServerName, InstanceName, ServiceAcctType, ServiceAcctDomain, ServiceAcctName)
            VALUES (@@SERVERNAME, @@SERVICENAME, 6, 
				(SUBSTRING(@SSISService, 1, CHARINDEX('\', @SSISService) - 1)), 
				(SUBSTRING(@SSISService, (CHARINDEX('\', @SSISService) + 1), (LEN(@SSISService)))));

-- evaluate / save the sql Distributed Replay Client service account
IF (@RtrnCd = 0) AND (@DCOMService IS NOT NULL) AND (LOWER(@DCOMService) NOT IN ('localsystem', 'localservice'))   
MERGE ##temptable AS target
    USING (SELECT @@SERVERNAME, @@SERVICENAME) AS source (ServerNameIN, ServiceNameIN)
    ON ((target.ServerName = source.ServerNameIN) AND (target.InstanceName = source.ServiceNameIN)
		AND (ServiceAcctType = 7))
    WHEN MATCHED THEN 
        UPDATE SET ServiceAcctDomain = (SUBSTRING(@DCOMService, 1, CHARINDEX('\', @DCOMService) - 1)),
			ServiceAcctName = (SUBSTRING(@DCOMService, (CHARINDEX('\', @DCOMService) + 1), (LEN(@DCOMService))))
        WHEN NOT MATCHED THEN  
            INSERT (ServerName, InstanceName, ServiceAcctType, ServiceAcctDomain, ServiceAcctName)
            VALUES (@@SERVERNAME, @@SERVICENAME, 7, 
				(SUBSTRING(@DCOMService, 1, CHARINDEX('\', @DCOMService) - 1)), 
				(SUBSTRING(@DCOMService, (CHARINDEX('\', @DCOMService) + 1), (LEN(@DCOMService)))));

-- evaluate / save the sql VSS Writer service account
IF (@RtrnCd = 0) AND (@VSSService IS NOT NULL) AND (LOWER(@VSSService) NOT IN ('localsystem', 'localservice'))  
MERGE ##temptable AS target
    USING (SELECT @@SERVERNAME, @@SERVICENAME) AS source (ServerNameIN, ServiceNameIN)
    ON ((target.ServerName = source.ServerNameIN) AND (target.InstanceName = source.ServiceNameIN)
		AND (ServiceAcctType = 9))
    WHEN MATCHED THEN 
        UPDATE SET ServiceAcctDomain = 'N/A',
			ServiceAcctName = @VSSService
        WHEN NOT MATCHED THEN 
	INSERT (ServerName, InstanceName, ServiceAcctType, ServiceAcctDomain, ServiceAcctName)
            VALUES (@@SERVERNAME, @@SERVICENAME, 9, 'N/A', @VSSService);
ELSE IF (LOWER(@VSSService) NOT IN ('localsystem', 'localservice'))  
MERGE ##temptable AS target
    USING (SELECT @@SERVERNAME, @@SERVICENAME) AS source (ServerNameIN, ServiceNameIN)
    ON ((target.ServerName = source.ServerNameIN) AND (target.InstanceName = source.ServiceNameIN)
		AND (ServiceAcctType = 9))
    WHEN MATCHED THEN 
        UPDATE SET ServiceAcctDomain = (SUBSTRING(@VSSService, 1, CHARINDEX('\', @VSSService) - 1)),
			ServiceAcctName = (SUBSTRING(@VSSService, (CHARINDEX('\', @VSSService) + 1), (LEN(@VSSService))))
        WHEN NOT MATCHED THEN  
            INSERT (ServerName, InstanceName, ServiceAcctType, ServiceAcctDomain, ServiceAcctName)
            VALUES (@@SERVERNAME, @@SERVICENAME, 9, 
				(SUBSTRING(@VSSService, 1, CHARINDEX('\', @VSSService) - 1)), 
				(SUBSTRING(@VSSService, (CHARINDEX('\', @VSSService) + 1), (LEN(@VSSService)))));

UPDATE master.dbo.SQLServiceAccounts 
SET ServiceAcctDomain = T.ServiceAcctDomain,
ServiceAcctName = T.ServiceAcctName
FROM ##temptable AS T
JOIN master.dbo.SQLServiceAccounts AS D
ON D.[ServerName] = T.[ServerName]
AND D.InstanceName = T.InstanceName
AND D.ServiceAcctType = T.ServiceAcctType
WHERE D.[ServerName] = @@SERVERNAME 
AND D.InstanceName = @@SERVICENAME
 

INSERT INTO master.dbo.SQLServiceAccounts 
(ServerName, InstanceName, ServiceAcctType, ServiceAcctDomain, ServiceAcctName, DateAdded)
SELECT ServerName, InstanceName, ServiceAcctType, ServiceAcctDomain, ServiceAcctName, GETDATE()
FROM ##temptable AS T
WHERE NOT EXISTS (SELECT D.ServerName, D.InstanceName, D.ServiceAcctType, D.ServiceAcctDomain, D.ServiceAcctName, D.DateAdded 
FROM master.dbo.SQLServiceAccounts AS D
WHERE D.[ServerName] = @@SERVERNAME 
AND D.InstanceName = @@SERVICENAME
AND D.ServiceAcctType = T.ServiceAcctType)
AND LOWER(ServiceAcctName) NOT IN ('localsystem', 'localservice')  
 
SELECT @RtrnCd 

--select * from ##temptable

drop table ##temptable





