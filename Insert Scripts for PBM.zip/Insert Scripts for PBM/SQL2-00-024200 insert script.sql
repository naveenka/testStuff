--INSERT INTO master.dbo.GeneralException
--           ([STIGItem]
--           ,[Server]
--           ,[Instance]
--           ,[ExceptionValue]
--           ,[Comments]
--           ,[ModifiedBy]
--           ,[CreateDate])
Select 105, @@SERVERNAME, @@SERVICENAME, credential_id, SUSER_SNAME(), GETDATE()
--SELECT *
FROM [master].sys.master_key_passwords
WHERE credential_id NOT IN (SELECT ExceptionValue FROM master.dbo.GeneralException
	WHERE STIGItem = 105
	AND [Server] = @@SERVERNAME
	AND Instance = @@SERVICENAME) 