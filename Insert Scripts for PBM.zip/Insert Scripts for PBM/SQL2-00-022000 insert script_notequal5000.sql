--INSERT INTO master.dbo.GeneralException
--           ([STIGItem]
--           ,[Server]
--           ,[Instance]
--           ,[ExceptionValue]
--           ,[Comments]
--           ,[ModifiedBy]
--           ,[CreateDate])
Select 147, @@SERVERNAME, @@SERVICENAME, value_in_use, SUSER_SNAME(), GETDATE()
--SELECT * 
FROM sys.configurations
WHERE configuration_id = 103
AND value <> 5000  
AND value_in_use NOT IN (SELECT ExceptionValue FROM master.dbo.GeneralException
	WHERE STIGItem = 147
	AND [Server] = @@SERVERNAME
	AND Instance = @@SERVICENAME) 