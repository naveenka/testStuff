--INSERT INTO master.dbo.GeneralException
--           ([STIGItem]
--           ,[Server]
--           ,[Instance]
--           ,[ExceptionValue]
--           ,[Comments]
--           ,[ModifiedBy]
--           ,[CreateDate])
Select 88, @@SERVERNAME, @@SERVICENAME, name, 'SA Used', SUSER_SNAME(), GETDATE()
--Select * 
from sys.sql_logins 
where name = SUSER_SNAME(0x01)
and is_disabled = 0
AND 'SA Used' NOT IN (SELECT ExceptionValue FROM master.dbo.GeneralException
	WHERE STIGItem = 88
	AND [Server] = @@SERVERNAME
	AND Instance = @@SERVICENAME) 