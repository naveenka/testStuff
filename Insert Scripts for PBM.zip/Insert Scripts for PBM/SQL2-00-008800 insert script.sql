--INSERT INTO master.dbo.PermissionException
--           ([STIGItem]
--           ,[Server]
--           ,[Instance]
--           ,[PermissionValue]
--           ,[GranteePersonName]
--           ,[Comments]
--           ,[ModifiedBy]
--           ,[CreateDate])
SELECT 111, @@SERVERNAME, @@SERVICENAME, permission_name, pr.name, 'Assigned information access corresponds to user job function',SUSER_SNAME(), GETDATE()
FROM sys.server_permissions pe
JOIN sys.server_principals pr
ON pe.grantee_principal_id = pr.principal_id
JOIN sys.server_principals ps
ON pe.grantor_principal_id = ps.principal_id
LEFT JOIN sys.server_principals us
ON us.principal_id = pe.major_id
WHERE pr.type IN ('K', 'S', 'U', 'R')
AND pe.grantee_principal_id > 10
AND NOT pr.name IN ('##MS_PolicyEventProcessingLogin##', '##MS_PolicyTsqlExecutionLogin##',
'NT AUTHORITY\NETWORK SERVICE', 'NT AUTHORITY\SYSTEM', 'NT SERVICE\MSSQLSERVER',
'NT SERVICE\SQLSERVERAGENT', 'NT SERVICE\SQLWriter', 'NT SERVICE\Winmgmt')
AND pr.name COLLATE Latin1_General_CI_AS_KS_WS NOT IN (SELECT [GranteePersonName] FROM master.dbo.PermissionException 
	WHERE STIGItem = 111
    AND PermissionValue = [permission_name] COLLATE Latin1_General_CI_AS_KS_WS 
	AND [GranteePersonName] = pr.name
	AND [Server] = @@SERVERNAME 
	AND Instance = @@SERVICENAME) and permission_name <> 'connect sql'