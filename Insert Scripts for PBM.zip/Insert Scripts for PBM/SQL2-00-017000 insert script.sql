--INSERT INTO master.dbo.GeneralException
--           ([STIGItem]
--           ,[Server]
--           ,[Instance]
--           ,[ExceptionValue]
--		   ,[Comments]
--           ,[ModifiedBy]
--           ,[CreateDate])

Select DISTINCT 136, @@SERVERNAME, @@SERVICENAME, servicename, 'Used database components'
           ,SUSER_SNAME(), GETDATE()
--SELECT * 
FROM sys.dm_server_services
WHERE startup_type <> 4
AND servicename COLLATE Latin1_General_CI_AS_KS_WS NOT IN (SELECT ExceptionValue FROM master.dbo.GeneralException
	WHERE STIGItem = 136
	AND [Server] = @@SERVERNAME
	AND Instance = @@SERVICENAME) 