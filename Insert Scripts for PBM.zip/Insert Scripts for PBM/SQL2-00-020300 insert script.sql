--INSERT INTO master.dbo.PermissionException
--           ([STIGItem]
--           ,[Server]
--           ,[Instance]
--           ,[PermissionValue]
--           ,[GranteePersonName]
--           ,[Comments]
--           ,[ModifiedBy]
--           ,[CreateDate])
SELECT 121, @@SERVERNAME, @@SERVICENAME, 'sysadmin', spU.name, 'Authorized Role',SUSER_SNAME(), GETDATE()
--SELECT spU.name, 'sysadmin'
FROM sys.server_principals AS spR
JOIN sys.server_role_members AS srm
ON spR.principal_id = srm.role_principal_id
JOIN sys.server_principals AS spU
ON srm.member_principal_id = spU.principal_id
WHERE spR.[type] = 'R'
AND srm.role_principal_id = 3
AND spU.name COLLATE Latin1_General_CI_AS_KS_WS  NOT IN (SELECT GranteePersonName FROM master.dbo.PermissionException 
	WHERE STIGItem = 121
                AND [PermissionValue] = 'sysadmin'
	AND [Server] = @@SERVERNAME
	AND Instance = @@SERVICENAME)
UNION
SELECT 121, @@SERVERNAME, @@SERVICENAME, 'securityadmin', spU.name, '',SUSER_SNAME(), GETDATE()
--SELECT spU.name, 'securityadmin'
FROM sys.server_principals AS spR
JOIN sys.server_role_members AS srm
ON spR.principal_id = srm.role_principal_id
JOIN sys.server_principals AS spU
ON srm.member_principal_id = spU.principal_id
WHERE spR.[type] = 'R'
AND srm.role_principal_id = 4
AND spU.name COLLATE Latin1_General_CI_AS_KS_WS NOT IN (SELECT GranteePersonName FROM master.dbo.PermissionException 
	WHERE STIGItem = 121
                AND [PermissionValue] = 'securityadmin'
	AND [Server] = @@SERVERNAME
	AND Instance = @@SERVICENAME)
UNION
SELECT 121, @@SERVERNAME, @@SERVICENAME, 'serveradmin', spU.name, '',SUSER_SNAME(), GETDATE()
--SELECT spU.name, 'serveradmin'
FROM sys.server_principals AS spR
JOIN sys.server_role_members AS srm
ON spR.principal_id = srm.role_principal_id
JOIN sys.server_principals AS spU
ON srm.member_principal_id = spU.principal_id
WHERE spR.[type] = 'R'
AND srm.role_principal_id = 5
AND spU.name COLLATE Latin1_General_CI_AS_KS_WS NOT IN (SELECT GranteePersonName FROM master.dbo.PermissionException 
	WHERE STIGItem = 121
                AND [PermissionValue] = 'serveradmin'
	AND [Server] = @@SERVERNAME
	AND Instance = @@SERVICENAME)
UNION
SELECT 121, @@SERVERNAME, @@SERVICENAME, 'setupadmin', spU.name, '',SUSER_SNAME(), GETDATE()
--SELECT spU.name, 'setupadmin'
FROM sys.server_principals AS spR
JOIN sys.server_role_members AS srm
ON spR.principal_id = srm.role_principal_id
JOIN sys.server_principals AS spU
ON srm.member_principal_id = spU.principal_id
WHERE spR.[type] = 'R'
AND srm.role_principal_id = 6
AND spU.name COLLATE Latin1_General_CI_AS_KS_WS NOT IN (SELECT GranteePersonName FROM master.dbo.PermissionException 
	WHERE STIGItem = 121
                AND [PermissionValue] = 'setupadmin'
	AND [Server] = @@SERVERNAME
	AND Instance = @@SERVICENAME)
UNION
SELECT 121, @@SERVERNAME, @@SERVICENAME, 'processadmin', spU.name, '',SUSER_SNAME(), GETDATE()
--SELECT spU.name, 'processadmin'
FROM sys.server_principals AS spR
JOIN sys.server_role_members AS srm
ON spR.principal_id = srm.role_principal_id
JOIN sys.server_principals AS spU
ON srm.member_principal_id = spU.principal_id
WHERE spR.[type] = 'R'
AND srm.role_principal_id = 7
AND spU.name COLLATE Latin1_General_CI_AS_KS_WS NOT IN (SELECT GranteePersonName FROM master.dbo.PermissionException 
	WHERE STIGItem = 121
                AND [PermissionValue] = 'processadmin'
	AND [Server] = @@SERVERNAME
	AND Instance = @@SERVICENAME)
UNION
SELECT 121, @@SERVERNAME, @@SERVICENAME, 'diskadmin', spU.name, '',SUSER_SNAME(), GETDATE()
--SELECT spU.name, 'diskadmin'
FROM sys.server_principals AS spR
JOIN sys.server_role_members AS srm
ON spR.principal_id = srm.role_principal_id
JOIN sys.server_principals AS spU
ON srm.member_principal_id = spU.principal_id
WHERE spR.[type] = 'R'
AND srm.role_principal_id = 8
AND spU.name COLLATE Latin1_General_CI_AS_KS_WS NOT IN (SELECT GranteePersonName FROM master.dbo.PermissionException 
	WHERE STIGItem = 121
                AND [PermissionValue] = 'diskadmin'
	AND [Server] = @@SERVERNAME
	AND Instance = @@SERVICENAME)
UNION
SELECT 121, @@SERVERNAME, @@SERVICENAME, 'dbcreator', spU.name, '',SUSER_SNAME(), GETDATE()
--SELECT spU.name, 'dbcreator'
FROM sys.server_principals AS spR
JOIN sys.server_role_members AS srm
ON spR.principal_id = srm.role_principal_id
JOIN sys.server_principals AS spU
ON srm.member_principal_id = spU.principal_id
WHERE spR.[type] = 'R'
AND srm.role_principal_id = 9
AND spU.name COLLATE Latin1_General_CI_AS_KS_WS NOT IN (SELECT GranteePersonName FROM master.dbo.PermissionException 
	WHERE STIGItem = 121
                AND [PermissionValue] = 'dbcreator'
	AND [Server] = @@SERVERNAME
	AND Instance = @@SERVICENAME)
UNION
SELECT 121, @@SERVERNAME, @@SERVICENAME, 'bulkadmin', spU.name, '',SUSER_SNAME(), GETDATE()
--SELECT spU.name, 'bulkadmin'
FROM sys.server_principals AS spR
JOIN sys.server_role_members AS srm
ON spR.principal_id = srm.role_principal_id
JOIN sys.server_principals AS spU
ON srm.member_principal_id = spU.principal_id
WHERE spR.[type] = 'R'
AND srm.role_principal_id = 10
AND spU.name COLLATE Latin1_General_CI_AS_KS_WS NOT IN (SELECT GranteePersonName FROM master.dbo.PermissionException 
	WHERE STIGItem = 121
                AND [PermissionValue] = 'bulkadmin'
	AND [Server] = @@SERVERNAME
	AND Instance = @@SERVICENAME)