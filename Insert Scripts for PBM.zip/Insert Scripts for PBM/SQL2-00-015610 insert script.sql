EXEC sp_MSforeachdb '
USE [?];
CREATE TABLE #temptbl(ServerRole VARCHAR(50), Description VARCHAR(500))
INSERT INTO #temptbl EXEC sp_helpsrvrole
--INSERT INTO master.dbo.GeneralException
 --          ([STIGItem]
 --          ,[Server]
 --          ,[Instance]
 --          ,[ExceptionValue]
 --          ,[Comments]
 --          ,[ModifiedBy]
 --          ,[CreateDate])
Select 139, @@SERVERNAME, @@SERVICENAME, DB_NAME(), ServerRole, SUSER_SNAME(), GETDATE()
FROM (SELECT ServerRole FROM #temptbl) AS ServerRole
	INNER JOIN sys.databases D ON D.Name = DB_NAME()
WHERE IS_SRVROLEMEMBER(ServerRole, SUSER_SNAME(D.owner_sid)) = 1
AND	DB_NAME()  <>  ''msdb''
AND	D.is_trustworthy_on = 1
AND ISNULL(''?'', '''') NOT IN (SELECT ExceptionValue FROM master.dbo.GeneralException
	WHERE STIGItem = 139
	AND [Server] = @@SERVERNAME
	AND Instance = @@SERVICENAME)  

DROP TABLE #temptbl '

