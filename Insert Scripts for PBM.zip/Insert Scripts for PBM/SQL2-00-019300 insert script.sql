use master;
--INSERT INTO master.dbo.GeneralException
--           ([STIGItem]
--           ,[Server]
--           ,[Instance]
--           ,[ExceptionValue]
--           ,[Comments]
--           ,[ModifiedBy]
--           ,[CreateDate])

Select 120, @@SERVERNAME, @@SERVICENAME, db_name(database_id), 'Database encryption not required',SUSER_SNAME(), GETDATE()
--SELECT ''?'', *
  FROM sys.dm_database_encryption_keys
 WHERE encryption_state != 3
 AND database_id > 4
 AND db_name(database_id) NOT IN (SELECT ExceptionValue FROM master.dbo.GeneralException
	WHERE STIGItem = 120
	AND [Server] = @@SERVERNAME
	AND Instance = @@SERVICENAME)  


