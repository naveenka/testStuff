--this policy will flag items that have been created in the last 7 days
--The table contains all non-Microsoft created items.

EXEC sp_MSforeachdb '
USE [?];
SELECT * 
INTO #temptableB
FROM master.dbo.TriggerChange  
WHERE Server = @@SERVERNAME 
AND Instance = @@SERVICENAME
AND DBName = ''?'' 
IF db_id() <> 2 
--INSERT INTO master.dbo.TriggerChange (
--[STIGItem] ,[Server] ,[Instance] ,[DBName] ,[ObjectID] ,[Statement] ,[Type]
--      ,[Comments] ,[CreateDate] ,[ModifyDate] ,[RecordDate] )
SELECT 82 as STIGItem, @@SERVERNAME as Server, @@SERVICENAME as Instance, ''?'' as DBName, m.object_id as ObjectID, 
SUBSTRING(definition, 1, 2000) as Statement, type_desc as Type, '''' as Comments, create_date as CreateDate, modify_date as ModifyDate, GETDATE() as RecordDate
from sys.sql_modules m
INNER JOIN sys.objects o on m.object_id = o.object_id
WHERE type_desc like ''%trigger%''
AND modify_date > DATEADD(dd, DATEDIFF(dd, 0, GETDATE() - 7), 0)
AND NOT EXISTS (
SELECT * FROM #temptableB AS f
WHERE f.ObjectID = m.object_id
--AND (f.Statement = SUBSTRING(m.definition, 1, 2000) COLLATE SQL_Latin1_General_CP1_CI_AS) 
--OR f.Statement IS NULL
)'

