USE MASTER;

DECLARE @admin_Account_name sysname
SET @admin_Account_name = 'NO admin ACCOUNT found'
DECLARE @server_name sysname
SET @server_name = 'NO Server found'

SELECT @server_name = name FROM sys.servers
 WHERE server_id = 0
SET @admin_Account_name = @server_name  + '\Administrator'

--INSERT INTO master.dbo.PermissionException
--           ([STIGItem]
--           ,[Server]
--           ,[Instance]
--           ,[PermissionValue]
--           ,[GranteePersonName]
--           ,[Comments]
--			 ,[ModifiedBy]
--           ,[CreateDate])
SELECT 100, @@SERVERNAME, @@SERVICENAME, permission_name, pr.name, 'Authorized Server Role',SUSER_SNAME(), GETDATE()
--SELECT *
FROM sys.server_permissions pe
JOIN sys.server_principals pr
ON pe.grantee_principal_id = pr.principal_id
JOIN sys.server_principals ps
ON pe.grantor_principal_id = ps.principal_id
LEFT JOIN sys.server_principals us
ON us.principal_id = pe.major_id
WHERE pr.type IN ('R')
AND pe.grantee_principal_id > 10
AND NOT pr.name IN ('##MS_PolicyEventProcessingLogin##', '##MS_PolicyTsqlExecutionLogin##',
'NT AUTHORITY\NETWORK SERVICE', 'NT AUTHORITY\SYSTEM', 'NT SERVICE\MSSQLSERVER',
'NT SERVICE\SQLSERVERAGENT', 'NT SERVICE\SQLWriter', 'NT SERVICE\Winmgmt')
AND NOT pr.name COLLATE Latin1_General_CI_AS_KS_WS = @admin_Account_name
AND pr.name COLLATE Latin1_General_CI_AS_KS_WS NOT IN (SELECT [GranteePersonName] FROM master.dbo.PermissionException 
	WHERE STIGItem = 100
                AND PermissionValue = [permission_name] COLLATE Latin1_General_CI_AS_KS_WS 
	AND [GranteePersonName] = pr.name 
	AND [Server] = @@SERVERNAME
	AND Instance = @@SERVICENAME) 


	
