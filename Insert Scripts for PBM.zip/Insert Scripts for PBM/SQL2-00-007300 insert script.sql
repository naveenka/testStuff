--INSERT INTO master.dbo.GeneralException
--           ([STIGItem]
--           ,[Server]
--           ,[Instance]
--           ,[ExceptionValue]
--           ,[Comments]
--           ,[ModifiedBy]
--           ,[CreateDate])

Select 52, @@SERVERNAME, @@SERVICENAME, name, '',SUSER_SNAME(), GETDATE()
--Select *
FROM 
       sys.server_permissions what 
       INNER JOIN sys.server_principals who
              ON who.principal_id = what.grantee_principal_id
WHERE
       what.permission_name = 'Shutdown'
AND    who.type_desc = 'SERVER_ROLE'
AND name COLLATE Latin1_General_CI_AS_KS_WS NOT IN (SELECT ExceptionValue FROM master.dbo.GeneralException
	WHERE STIGItem = 52
	AND [Server] = @@SERVERNAME
	AND Instance = @@SERVICENAME) 