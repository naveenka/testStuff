CREATE TABLE #tmptbl (results VARCHAR(200))

DECLARE @sqlservice AS VARCHAR(500)
DECLARE @sqlagent AS VARCHAR(500)
DECLARE @sqlfts AS VARCHAR(500)
DECLARE @SSAS AS VARCHAR(500)
DECLARE @SSRS AS VARCHAR(500)

SET @sqlagent =  'sc query SQLAgent$' + CAST(@@SERVICENAME AS VARCHAR)
SET @sqlservice = 'sc query MSSQL$' + CAST(@@SERVICENAME AS VARCHAR)
SET @sqlfts = 'sc query MSSQLFDLauncher$' + CAST(@@SERVICENAME AS VARCHAR)
SET @SSAS = 'sc query MSOLAP$' + CAST(@@SERVICENAME AS VARCHAR)
SET @SSRS = 'sc query ReportServer$' + CAST(@@SERVICENAME AS VARCHAR)

EXEC sp_configure 'show advanced options', 1
RECONFIGURE
EXEC sp_configure 'xp_cmdshell', 1
RECONFIGURE
--EXEC xp_cmdshell 'powershell "get-service | where-object {$_.ServiceName -eq ''MsDtsServer110''}"'
INSERT INTO #tmptbl 
EXEC xp_cmdshell 'sc query MsDtsServer110'
INSERT INTO #tmptbl 
EXEC xp_cmdshell 'sc query SQLWriter'
INSERT INTO #tmptbl 
EXEC xp_cmdshell 'sc query SQLBrowser'
INSERT INTO #tmptbl 
EXEC xp_cmdshell 'sc query "SQL Server Distributed Replay Client"'

IF CAST(@@SERVICENAME AS VARCHAR) = 'MSSQLSERVER'
BEGIN
INSERT INTO #tmptbl EXEC xp_cmdshell 'sc query SQLSERVERAgent' 
INSERT INTO #tmptbl EXEC xp_cmdshell 'sc query MSSQLSERVER'
INSERT INTO #tmptbl EXEC xp_cmdshell 'sc query MSSQLFDLauncher'
INSERT INTO #tmptbl EXEC xp_cmdshell 'sc query MSOLAP'
INSERT INTO #tmptbl EXEC xp_cmdshell 'sc query ReportServer'
END
ELSE BEGIN
INSERT INTO #tmptbl EXEC xp_cmdshell @sqlagent
INSERT INTO #tmptbl EXEC xp_cmdshell @sqlservice
INSERT INTO #tmptbl EXEC xp_cmdshell @sqlfts
INSERT INTO #tmptbl EXEC xp_cmdshell @SSAS
INSERT INTO #tmptbl EXEC xp_cmdshell @SSRS
END

EXEC sp_configure 'xp_cmdshell', 0
RECONFIGURE
--INSERT INTO master.dbo.GeneralException
--           ([STIGItem]
--           ,[Server]
--           ,[Instance]
--           ,[ExceptionValue]
--		   ,[Comments]
--           ,[ModifiedBy]
--           ,[CreateDate])

Select DISTINCT 135, @@SERVERNAME, @@SERVICENAME, SUBSTRING(results, 15, LEN(Results) - 14) , 'Service installation is required',SUSER_SNAME(), GETDATE()
--SELECT COUNT(*) 
FROM #tmptbl 
WHERE results LIKE 'SERVICE_NAME:%'
AND SUBSTRING(results, 15, LEN(Results) - 14) NOT IN (SELECT ExceptionValue 
	FROM master.dbo.GeneralException
	WHERE STIGItem = 135
	AND [Server] = @@SERVERNAME
	AND Instance = @@SERVICENAME)
DROP TABLE #tmptbl



