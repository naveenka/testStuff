USE master
go

--INSERT INTO master.dbo.GeneralException
--           ([STIGItem]
--           ,[Server]
--           ,[Instance]
--           ,[ExceptionValue]
--           ,[Comments]
--           ,[ModifiedBy]
--           ,[CreateDate])

Select 137, @@SERVERNAME, @@SERVICENAME, name, 'SMK was backed up',SUSER_SNAME(), GETDATE()
-- SELECT *
     FROM sys.symmetric_keys  
WHERE name = '##MS_ServiceMasterKey##' 
AND 'SMK' NOT IN (SELECT ExceptionValue FROM master.dbo.GeneralException
	WHERE STIGItem = 137
	AND [Server] = @@SERVERNAME
	AND Instance = @@SERVICENAME)
