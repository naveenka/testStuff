--INSERT INTO master.dbo.GeneralException
--           ([STIGItem]
--           ,[Server]
--           ,[Instance]
--           ,[ExceptionValue]
--           ,[Comments]
--           ,[ModifiedBy]
--           ,[CreateDate])

Select 79, @@SERVERNAME, @@SERVICENAME, 'server shutdown', '',SUSER_SNAME(), GETDATE()
--SELECT *
FROM sys.server_file_audits
WHERE on_failure != 1
AND NOT EXISTS (SELECT * FROM master.dbo.GeneralException
	WHERE STIGItem = 79
	AND [Server] = @@SERVERNAME
	AND Instance = @@SERVICENAME)

    
