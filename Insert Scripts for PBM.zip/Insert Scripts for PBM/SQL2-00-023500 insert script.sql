--INSERT INTO master.dbo.GeneralException
--           ([STIGItem]
--           ,[Server]
--           ,[Instance]
--           ,[ExceptionValue]
--		   ,[Comments]
--           ,[ModifiedBy]
--           ,[CreateDate])

Select 101, @@SERVERNAME, @@SERVICENAME, name, 'Job Authorized',SUSER_SNAME(), GETDATE()
--SELECT *
FROM msdb.dbo.sysjobs
WHERE name COLLATE Latin1_General_CI_AS_KS_WS NOT IN (SELECT ExceptionValue FROM master.dbo.GeneralException
	WHERE STIGItem = 101
	AND [Server] = @@SERVERNAME
	AND Instance = @@SERVICENAME )