
--DROP TABLE #tempInstanceNames

EXEC sp_configure 'show advanced options', 1
RECONFIGURE
EXEC sp_configure 'xp_cmdshell', 1
RECONFIGURE

DECLARE @BinnPath VARCHAR(450)
DECLARE @SQL VARCHAR(1000)
DECLARE @CntOf INT
DECLARE @Auditpath VARCHAR(100)

SET @Auditpath = (select SUBSTRING(audit_file_path, 1, CHARINDEX('Audit', audit_file_path) + 4) 
from sys.dm_server_audit_status)

--SET @SQL = 'del /f R:\Audit\FCIV\dbsha.xml /q'
SET @SQL = 'del /f ' + @Auditpath + '\FCIV\dbsha.xml /q'

EXEC xp_cmdshell @SQL, no_output

--get instance names
CREATE TABLE #tempInstanceNames
(  InstanceName		VARCHAR(100),
   RegPath			VARCHAR(500),
   DefaultDataPath	VARCHAR(MAX)  )

INSERT INTO #tempInstanceNames (InstanceName, RegPath)
EXEC master..xp_instance_regenumvalues
	@rootkey = N'HKEY_LOCAL_MACHINE',
	@key = N'SOFTWARE\\Microsoft\\Microsoft SQL Server\\Instance Names\\SQL'

--SELECT InstanceName, RegPath, DefaultDataPath FROM #tempInstanceNames

--get SQLBinRoot
SET @SQL = 'DECLARE @returnValue NVARCHAR(100)'
SELECT @SQL = @SQL + CHAR(13) +
'EXEC master.dbo.xp_regread
@rootkey = N''HKEY_LOCAL_MACHINE'',
@key = N''SOFTWARE\Microsoft\Microsoft SQL Server\' + RegPath + '\Setup'',
@value_name = N''SQLBinRoot'',
@Data = @returnValue OUTPUT;

UPDATE #tempInstanceNames SET DefaultDataPath = @returnValue
WHERE RegPath = ''' + RegPath + '''' + CHAR(13) FROM #tempInstanceNames
WHERE InstanceName = @@SERVICENAME

EXEC (@SQL)
--SELECT * FROM #tempInstanceNames

SET @BinnPath = (SELECT DefaultDataPath FROM #tempInstanceNames 
WHERE InstanceName = @@SERVICENAME)

SET @SQL = @Auditpath + '\FCIV\fciv.exe "' + @BinnPath + '" -r -sha1 -xml ' + @Auditpath + '\FCIV\dbsha.xml >nul 2>&1'
--print @SQL
EXEC xp_cmdshell @SQL, no_output 

EXEC sp_configure 'xp_cmdshell', 0
RECONFIGURE

--*****************************
--Import the file
CREATE TABLE ##XMLwithOpenXML
(
Id INT IDENTITY PRIMARY KEY,
XMLData XML,
LoadedDateTime DATETIME
)

SET @SQL = 'INSERT INTO ##XMLwithOpenXML(XMLData, LoadedDateTime)
SELECT CONVERT(XML, BulkColumn) AS BulkColumn, GETDATE() 
FROM OPENROWSET(BULK ''' + @Auditpath + '\FCIV\dbsha.xml'', SINGLE_BLOB) AS x;'
--SELECT @sql as 'sql'
EXEC (@SQL)

---extract data
DECLARE @XML AS XML, @hDoc AS INT

SET @XML = (SELECT XMLData FROM ##XMLwithOpenXML)

EXEC sp_xml_preparedocument @hDoc OUTPUT, @XML

SELECT FilePath, Chksum
INTO ##XMLtoTABLE
FROM OPENXML(@hDoc, 'FCIV/FILE_ENTRY')
WITH 
(
FilePath [varchar](350) 'name',
Chksum [varchar](100) 'SHA1'
)

EXEC sp_xml_removedocument @hDoc

SET @CntOf = (SELECT MAX(CountOf) FROM dbo.DatabaseBinnChecksum 
WHERE Servername = @@SERVERNAME AND Instancename = @@SERVICENAME)

IF @CntOf IS NULL SET @CntOf = 0

--INSERT INTO dbo.DatabaseBinnChecksum 
--	([Servername]
--    ,[Instancename]
--    ,[BinnPath]
--    ,[FilePath]
--    ,[Chksum]
--    ,[CountOf]
--    ,[ModifiedBy]
--    ,[ModifiedDate])
SELECT @@SERVERNAME AS 'Servername', @@SERVICENAME AS 'Instancename', @BinnPath AS 'BinnPath', 
FilePath, Chksum, @CntOf + 1 AS 'CountOf', SUSER_SNAME() AS 'ModifiedBy', GETDATE() AS 'ModifiedDate' 
FROM ##XMLtoTABLE AS x 
WHERE NOT EXISTS (SELECT * FROM dbo.DatabaseBinnChecksum AS d
	WHERE d.Servername = @@SERVERNAME
	AND d.Instancename = @@SERVICENAME
	AND d.BinnPath = @BinnPath
	AND d.FilePath = x.FilePath
	AND d.Chksum = x.chksum)
	--AND d.CountOf = @CntOf)

DROP TABLE ##XMLwithOpenXML
DROP TABLE ##XMLtoTABLE
DROP TABLE #tempInstanceNames


