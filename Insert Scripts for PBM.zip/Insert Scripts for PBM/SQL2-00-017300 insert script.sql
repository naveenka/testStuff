CREATE TABLE ##temptable (
	[STIGItem] [int],
	[Server] [varchar](400) ,
	[Instance] [varchar](400) ,
	[ExceptionValue] [varchar](400) ,
	[DBName] [varchar](400) ,
	[ModifiedBy] [varchar](400) ,
	[CreateDate] [date] )

CREATE TABLE ##Exception (
Comments VARCHAR(500),
ExceptionValue VARCHAR(400)
)

CREATE UNIQUE CLUSTERED INDEX IX_1 ON ##Exception(comments, exceptionvalue)

INSERT INTO ##Exception
SELECT DISTINCT SUBSTRING(Comments, 38, LEN(Comments) - 37), ExceptionValue
FROM master.dbo.GeneralException
WHERE STIGItem = 93
	AND [Server] = @@SERVERNAME
	AND Instance = @@SERVICENAME 

--SELECT * FROM ##Exception

INSERT INTO ##temptable
EXEC sp_MSforeachdb '
IF ''?'' NOT IN (''tempDB'')
Select 93, @@SERVERNAME, @@SERVICENAME, name, ''Is authorized function or service in '' + ''?'',SUSER_SNAME(), GETDATE()
--SELECT count(*)
  FROM [?].sys.objects
 WHERE type in (''FN'', ''P'')
   AND is_ms_shipped <> 1 
AND name COLLATE SQL_Latin1_General_CP1_CI_AS NOT IN 
(SELECT ExceptionValue FROM ##Exception
WHERE Comments = ''?'') '

--select * from ##temptable

--INSERT INTO master.dbo.GeneralException
--           ([STIGItem]
--           ,[Server]
--           ,[Instance]
--           ,[ExceptionValue]
--           ,[Comments]
--           ,[ModifiedBy]
--           ,[CreateDate])
SELECT 93, @@SERVERNAME, @@SERVICENAME, [ExceptionValue], DBName, SUSER_SNAME(), GETDATE() 
FROM ##temptable
--order by [ExceptionValue]

DROP TABLE ##temptable
DROP TABLE ##Exception




