 --INSERT INTO master.dbo.GeneralException
 --          ([STIGItem]
 --          ,[Server]
 --          ,[Instance]
 --          ,[ExceptionValue]
 --          ,[Comments]
 --          ,[ModifiedBy]
 --          ,[CreateDate])

Select DISTINCT 102, @@SERVERNAME, @@SERVICENAME, 'Teammate', 'Cant use Windows Integrated Security',SUSER_SNAME(), GETDATE()
WHERE (SELECT COUNT(*) WHERE SERVERPROPERTY('IsIntegratedSecurityOnly') = 1)
+ (SELECT COUNT(*) FROM master.dbo.GeneralException
	WHERE STIGItem = 102
	AND [Server] = @@SERVERNAME
	AND Instance = @@SERVICENAME) = 0



	


--exec master.sys.xp_loginconfig 'login mode'

