--INSERT INTO master.dbo.GeneralException
--           ([STIGItem]
--           ,[Server]
--           ,[Instance]
--           ,[ExceptionValue]
--           ,[Comments]
--           ,[ModifiedBy]
--           ,[CreateDate])
Select 140, @@SERVERNAME, @@SERVICENAME, name, 'No Max Audit File Size Required',SUSER_SNAME(), GETDATE()
--Select *
FROM sys.server_file_audits
WHERE max_file_size = 0
AND name COLLATE Latin1_General_CI_AS_KS_WS NOT IN (SELECT ExceptionValue FROM master.dbo.GeneralException
	WHERE STIGItem = 140
	AND [Server] = @@SERVERNAME
	AND Instance = @@SERVICENAME)