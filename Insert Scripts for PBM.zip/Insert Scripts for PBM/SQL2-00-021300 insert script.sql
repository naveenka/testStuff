--INSERT INTO master.dbo.GeneralException
--           ([STIGItem]
--           ,[Server]
--           ,[Instance]
--           ,[ExceptionValue]
--           ,[Comments]
--           ,[ModifiedBy]
--           ,[CreateDate])

Select 96, @@SERVERNAME, @@SERVICENAME, name, '',SUSER_SNAME(), GETDATE()
--SELECT * 
FROM sys.dm_database_encryption_keys e 
RIGHT JOIN sys.databases d ON DB_NAME(e.database_id) = d.name 
WHERE d.name NOT IN ('master','model','msdb')
AND (e.encryption_state IS NULL
	OR e.encryption_state <> 3)
AND name COLLATE Latin1_General_CI_AS_KS_WS NOT IN (SELECT ExceptionValue FROM master.dbo.GeneralException
	WHERE STIGItem = 96
	AND [Server] = @@SERVERNAME
	AND Instance = @@SERVICENAME) 

  


