--INSERT INTO master.dbo.PermissionException
--           ([STIGItem]
--           ,[Server]
--           ,[Instance]
--           ,[PermissionValue]
--           ,[GranteePersonName]
--           ,[Comments]
--           ,[ModifiedBy]
--		     ,[CreateDate])

SELECT 117, @@SERVERNAME, @@SERVICENAME, 'Role: ' + SP2.[name] COLLATE DATABASE_DEFAULT AS 'ServerPermission'
, SP1.[name] AS 'Login', 'Authorized for specified permission',SUSER_SNAME(), GETDATE()
FROM sys.server_principals SP1
  JOIN sys.server_role_members SRM
    ON SP1.principal_id = SRM.member_principal_id
  JOIN sys.server_principals SP2
    ON SRM.role_principal_id = SP2.principal_id
WHERE  SP1.[name] COLLATE Latin1_General_CI_AS_KS_WS NOT IN (SELECT [GranteePersonName] FROM master.dbo.PermissionException 
	WHERE STIGItem = 117
    AND PermissionValue = 'Role: ' + SP2.[name] 
	AND [Server] = @@SERVERNAME 
	AND Instance = @@SERVICENAME) 
UNION ALL
SELECT DISTINCT 117, @@SERVERNAME, @@SERVICENAME, SPerm.state_desc + ' ' + SPerm.permission_name COLLATE DATABASE_DEFAULT AS 'ServerPermission', SP.[name] AS 'Login',  'Authorized for specified permission',SUSER_SNAME(), GETDATE()
  FROM sys.server_principals SP
  JOIN sys.server_permissions SPerm
    ON SP.principal_id = SPerm.grantee_principal_id
AND name COLLATE Latin1_General_CI_AS_KS_WS NOT IN (SELECT [GranteePersonName] FROM master.dbo.PermissionException 
	WHERE STIGItem = 117
    AND PermissionValue = SPerm.state_desc + ' ' + SPerm.permission_name COLLATE Latin1_General_CI_AS_KS_WS 
	AND [Server] = @@SERVERNAME 
	AND Instance = @@SERVICENAME)  