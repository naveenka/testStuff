SET NOCOUNT ON

DECLARE @SQLService  	NVARCHAR(60)
DECLARE @AgentService  	NVARCHAR(60)
DECLARE @FTService  	NVARCHAR(60)
DECLARE @SSASService  	NVARCHAR(60)
DECLARE @SSRSService  	NVARCHAR(60)
DECLARE @SSISService  	NVARCHAR(60)
DECLARE @DCOMService  	NVARCHAR(60)
DECLARE @DTCService  	NVARCHAR(60)
DECLARE @VSSService  	NVARCHAR(60)
DECLARE @Instance	  	NVARCHAR(60)
DECLARE @WorkingNm		NVARCHAR(60)
DECLARE @RKey			NVARCHAR(60)
DECLARE @RtrnCd			TINYINT

SET @RtrnCd = 0

SET @Instance = @@SERVICENAME

-- we get the instance aware service accounts below
IF @Instance = 'MSSQLSERVER' 
BEGIN

SET @WorkingNm = 'ReportServer' 
SET @RKey = 'SYSTEM\ControlSet001\Services\' + @WorkingNm + '\'	

-- get SSRS account
BEGIN TRY
EXEC xp_instance_regread @root_key  	= 'HKEY_LOCAL_MACHINE',
				@key   		= @RKey,
				@valuename  	= 'ObjectName',
				@value   	= @SSRSService output
END TRY
BEGIN CATCH
	SET @SSRSService = NULL
END CATCH
--SELECT @SSRSService as 'SSRSService'
END
ELSE
-- get this named instance services
BEGIN

SET @WorkingNm = 'ReportServer$' + @Instance	
SET @RKey = 'SYSTEM\ControlSet001\Services\' + @WorkingNm + '\'	

-- get SSRS account
BEGIN TRY
EXEC xp_instance_regread @root_key  	= 'HKEY_LOCAL_MACHINE',
				@key   		= @RKey,
				@valuename  	= 'ObjectName',
				@value   	= @SSRSService output
END TRY
BEGIN CATCH
	SET @SSRSService = NULL
END CATCH
--SELECT @SSRSService as 'SSRSService'
END

SELECT (CASE WHEN @SSRSService IS NULL THEN 0 ELSE 
(CASE WHEN (SELECT 1 FROM master.dbo.GeneralException
	WHERE STIGItem = 113
	AND [Server] = @@SERVERNAME
	AND Instance = @@SERVICENAME) IS NOT NULL THEN 0 ELSE 1 END) END)

/*
 INSERT INTO master.dbo.GeneralException
           ([STIGItem]
           ,[Server]
           ,[Instance]
           ,[ExceptionValue]
           ,[Comments]
           ,[ModifiedBy]
           ,[CreateDate])
Select 113, @@SERVERNAME, @@SERVICENAME, 'SSRS', '',SUSER_SNAME(), GETDATE()
*/