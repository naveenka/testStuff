DECLARE @RequiredActions TABLE (req_audit_action_name VARCHAR(100))

INSERT INTO @RequiredActions (req_audit_action_name)
VALUES ('SUCCESSFUL_LOGIN_GROUP') --14 
,('LOGOUT_GROUP') --15 
,('SERVER_STATE_CHANGE_GROUP') --18 
,('FAILED_LOGIN_GROUP') --20 
,('DATABASE_PERMISSION_CHANGE_GROUP') --102 
,('SCHEMA_OBJECT_PERMISSION_CHANGE_GROUP') --103 
,('SERVER_PRINCIPAL_CHANGE_GROUP') --104 
,('SERVER_PERMISSION_CHANGE_GROUP') --105 
--106 **deprecated 
,('LOGIN_CHANGE_PASSWORD_GROUP') --107 
,('SERVER_ROLE_MEMBER_CHANGE_GROUP') --108 
,('DATABASE_PRINCIPAL_CHANGE_GROUP')--109 
,('DATABASE_ROLE_MEMBER_CHANGE_GROUP') --110 
--111 **deprecated 
,('APPLICATION_ROLE_CHANGE_PASSWORD_GROUP') --112 
,('SCHEMA_OBJECT_CHANGE_GROUP') --113 
,('BACKUP_RESTORE_GROUP') --115 
,('DBCC_GROUP') --116 
,('AUDIT_CHANGE_GROUP') --117 
--118 **same as 113
,('DATABASE_CHANGE_GROUP') --128 
,('DATABASE_OBJECT_CHANGE_GROUP') --129 
--130 **same as 109
--131 **same as 131
,('SERVER_PRINCIPAL_IMPERSONATION_GROUP') --132 
,('DATABASE_PRINCIPAL_IMPERSONATION_GROUP') --133 
,('SERVER_OBJECT_OWNERSHIP_CHANGE_GROUP') --134  
,('DATABASE_OBJECT_OWNERSHIP_CHANGE_GROUP') --135 
,('DATABASE_OWNERSHIP_CHANGE_GROUP') --152 
,('SCHEMA_OBJECT_OWNERSHIP_CHANGE_GROUP') --153 
--170 **same as 105
,('SERVER_OBJECT_PERMISSION_CHANGE_GROUP') --171 
,('DATABASE_OBJECT_PERMISSION_CHANGE_GROUP') --172 
,('SERVER_OPERATION_GROUP') --173 
,('TRACE_CHANGE_GROUP') --175 
,('SERVER_OBJECT_CHANGE_GROUP') --176 
,('SERVER_PRINCIPAL_CHANGE_GROUP') --177 
,('DATABASE_OPERATION_GROUP') --178 
,('DATABASE_OBJECT_CHANGE_GROUP' )

--SELECT * FROM @RequiredActions

DECLARE @idof INT

SET @idof = (SELECT TOP 1 id FROM sys.traces
WHERE status = 1
AND path LIKE  '%cc_trace%')

--14, 15, 18, 20, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 
--112, 113, 115, 116, 117, 118, 128, 129, 130, 131, 132, 133, 134, 
--135, 152, 153, 170, 171, 172, 173, 175, 176, 177 and 178  




IF EXISTS (
--(SELECT ISNULL(
(SELECT req_audit_action_name as 'nameof' FROM @RequiredActions
EXCEPT 
(SELECT sd.audit_action_name FROM sys.server_audit_specification_details sd 
JOIN sys.server_audit_specifications as sp
ON sp.server_specification_id = sd.server_specification_id
JOIN sys.server_audits as sa 
ON sa.audit_guid = sp.audit_guid
JOIN sys.database_audit_specifications as ds
ON sa.audit_guid = ds.audit_guid
JOIN sys.database_audit_specification_details as dd
ON ds.database_specification_id = dd.database_specification_id
WHERE sa.is_state_enabled = 1
AND sp.is_state_enabled = 1
--AND sd.audit_action_name <> 'BACKUP_RESTORE_GROUP'
AND ds.is_state_enabled = 1) ) 
) SELECT 0 ELSE SELECT 1
--, 0) AS 'nameof' ) 
+ 
(SELECT COUNT(*) 
WHERE (14 in (SELECT eventid FROM ::fn_trace_geteventinfo(@idof))
	OR 14 in (SELECT eventid FROM ::fn_trace_geteventinfo(1)))
AND (15 in (SELECT eventid FROM ::fn_trace_geteventinfo(@idof))
	OR 15 in (SELECT eventid FROM ::fn_trace_geteventinfo(1)))
AND (18 in (SELECT eventid FROM ::fn_trace_geteventinfo(@idof))
	OR 18 in (SELECT eventid FROM ::fn_trace_geteventinfo(1)))
AND (20 in (SELECT eventid FROM ::fn_trace_geteventinfo(@idof))
	OR 20 in (SELECT eventid FROM ::fn_trace_geteventinfo(1)))
AND (102 in (SELECT eventid FROM ::fn_trace_geteventinfo(@idof))
	OR 102 in (SELECT eventid FROM ::fn_trace_geteventinfo(1)))
AND (103 in (SELECT eventid FROM ::fn_trace_geteventinfo(@idof))
	OR 103 in (SELECT eventid FROM ::fn_trace_geteventinfo(1)))
AND (104 in (SELECT eventid FROM ::fn_trace_geteventinfo(@idof))
	OR 104 in (SELECT eventid FROM ::fn_trace_geteventinfo(1)))
AND (105 in (SELECT eventid FROM ::fn_trace_geteventinfo(@idof))
	OR 105 in (SELECT eventid FROM ::fn_trace_geteventinfo(1)))
AND (106 in (SELECT eventid FROM ::fn_trace_geteventinfo(@idof))
	OR 106 in (SELECT eventid FROM ::fn_trace_geteventinfo(1)))
AND (107 in (SELECT eventid FROM ::fn_trace_geteventinfo(@idof))
	OR 107 in (SELECT eventid FROM ::fn_trace_geteventinfo(1)))
AND (108 in (SELECT eventid FROM ::fn_trace_geteventinfo(@idof))
	OR 108 in (SELECT eventid FROM ::fn_trace_geteventinfo(1)))
AND (109 in (SELECT eventid FROM ::fn_trace_geteventinfo(@idof))
	OR 109 in (SELECT eventid FROM ::fn_trace_geteventinfo(1)))
AND (110 in (SELECT eventid FROM ::fn_trace_geteventinfo(@idof))
	OR 110 in (SELECT eventid FROM ::fn_trace_geteventinfo(1)))
AND (111 in (SELECT eventid FROM ::fn_trace_geteventinfo(@idof))
	OR 111 in (SELECT eventid FROM ::fn_trace_geteventinfo(1)))
AND (112 in (SELECT eventid FROM ::fn_trace_geteventinfo(@idof))
	OR 112 in (SELECT eventid FROM ::fn_trace_geteventinfo(1)))
AND (113 in (SELECT eventid FROM ::fn_trace_geteventinfo(@idof))
	OR 113 in (SELECT eventid FROM ::fn_trace_geteventinfo(1)))
AND (115 in (SELECT eventid FROM ::fn_trace_geteventinfo(@idof))
	OR 115 in (SELECT eventid FROM ::fn_trace_geteventinfo(1)))
AND (116 in (SELECT eventid FROM ::fn_trace_geteventinfo(@idof))
	OR 116 in (SELECT eventid FROM ::fn_trace_geteventinfo(1)))
AND (117 in (SELECT eventid FROM ::fn_trace_geteventinfo(@idof))
	OR 117 in (SELECT eventid FROM ::fn_trace_geteventinfo(1)))
AND (118 in (SELECT eventid FROM ::fn_trace_geteventinfo(@idof))
	OR 118 in (SELECT eventid FROM ::fn_trace_geteventinfo(1)))
AND (128 in (SELECT eventid FROM ::fn_trace_geteventinfo(@idof))
	OR 128 in (SELECT eventid FROM ::fn_trace_geteventinfo(1)))
AND (129 in (SELECT eventid FROM ::fn_trace_geteventinfo(@idof))
	OR 129 in (SELECT eventid FROM ::fn_trace_geteventinfo(1)))
AND (130 in (SELECT eventid FROM ::fn_trace_geteventinfo(@idof))
	OR 130 in (SELECT eventid FROM ::fn_trace_geteventinfo(1)))
AND (131 in (SELECT eventid FROM ::fn_trace_geteventinfo(@idof))
	OR 131 in (SELECT eventid FROM ::fn_trace_geteventinfo(1)))
AND (132 in (SELECT eventid FROM ::fn_trace_geteventinfo(@idof))
	OR 132 in (SELECT eventid FROM ::fn_trace_geteventinfo(1)))
AND (133 in (SELECT eventid FROM ::fn_trace_geteventinfo(@idof))
	OR 133 in (SELECT eventid FROM ::fn_trace_geteventinfo(1)))
AND (134 in (SELECT eventid FROM ::fn_trace_geteventinfo(@idof))
	OR 134 in (SELECT eventid FROM ::fn_trace_geteventinfo(1)))
AND (135 in (SELECT eventid FROM ::fn_trace_geteventinfo(@idof))
	OR 135 in (SELECT eventid FROM ::fn_trace_geteventinfo(1)))
AND (152 in (SELECT eventid FROM ::fn_trace_geteventinfo(@idof))
	OR 152 in (SELECT eventid FROM ::fn_trace_geteventinfo(1)))
AND (153 in (SELECT eventid FROM ::fn_trace_geteventinfo(@idof))
	OR 153 in (SELECT eventid FROM ::fn_trace_geteventinfo(1)))
AND (170 in (SELECT eventid FROM ::fn_trace_geteventinfo(@idof))
	OR 170 in (SELECT eventid FROM ::fn_trace_geteventinfo(1)))
AND (171 in (SELECT eventid FROM ::fn_trace_geteventinfo(@idof))
	OR 171 in (SELECT eventid FROM ::fn_trace_geteventinfo(1)))
AND (172 in (SELECT eventid FROM ::fn_trace_geteventinfo(@idof))
	OR 172 in (SELECT eventid FROM ::fn_trace_geteventinfo(1)))
AND (173 in (SELECT eventid FROM ::fn_trace_geteventinfo(@idof))
	OR 173 in (SELECT eventid FROM ::fn_trace_geteventinfo(1)))
AND (175 in (SELECT eventid FROM ::fn_trace_geteventinfo(@idof))
	OR 175 in (SELECT eventid FROM ::fn_trace_geteventinfo(1)))
AND (176 in (SELECT eventid FROM ::fn_trace_geteventinfo(@idof))
	OR 176 in (SELECT eventid FROM ::fn_trace_geteventinfo(1)))
AND (177 in (SELECT eventid FROM ::fn_trace_geteventinfo(@idof))
	OR 177 in (SELECT eventid FROM ::fn_trace_geteventinfo(1)))
AND (178 in (SELECT eventid FROM ::fn_trace_geteventinfo(@idof))
	OR 178 in (SELECT eventid FROM ::fn_trace_geteventinfo(1)))
) 



