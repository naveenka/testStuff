
--INSERT INTO master.dbo.GeneralException
--           ([STIGItem]
--           ,[Server]
--           ,[Instance]
--           ,[ExceptionValue]
--           ,[Comments]
--           ,[ModifiedBy]
--           ,[CreateDate])
Select 143, @@SERVERNAME, @@SERVICENAME, name, 'Northwind Allowed',SUSER_SNAME(), GETDATE()
--select *
from sysdatabases 
where name like 'Northwind%'
AND name COLLATE Latin1_General_CI_AS_KS_WS NOT IN (SELECT ExceptionValue FROM master.dbo.GeneralException
	WHERE STIGItem = 143
	AND [Server] = @@SERVERNAME
	AND Instance = @@SERVICENAME) 