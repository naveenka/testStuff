--INSERT INTO master.dbo.GeneralException
--           ([STIGItem]
--           ,[Server]
--           ,[Instance]
--           ,[ExceptionValue]
--           ,[Comments]
--           ,[ModifiedBy]
--           ,[CreateDate])

Select 91, @@SERVERNAME, @@SERVICENAME, name, 'Group Account for Individual Users',SUSER_SNAME(), GETDATE()
--SELECT * 
FROM sys.server_principals
WHERE NOT TYPE IN ('C', 'R', 'U') 
AND NOT name IN ('##MS_PolicyEventProcessingLogin##', '##MS_PolicyTsqlExecutionLogin##', 'DOD-IG\SQLAdmin')
AND sid <> CONVERT(VARBINARY(85), 0x01)
AND name COLLATE Latin1_General_CI_AS_KS_WS NOT IN (SELECT ExceptionValue FROM master.dbo.GeneralException
	WHERE STIGItem = 91
	AND [Server] = @@SERVERNAME
	AND Instance = @@SERVICENAME) 